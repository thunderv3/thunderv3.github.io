# -*- coding: utf-8 -*-

import json
import os

import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs


ADDON_ID = "plugin.video.wm2026"

ADDON = xbmcaddon.Addon(id=ADDON_ID)

ADDON_PATH = xbmcvfs.translatePath(
    ADDON.getAddonInfo("path")
)


# ------------------------------------------------------------------
# Streams laden
# ------------------------------------------------------------------
def load_channels():

    channels_file = os.path.join(
        ADDON_PATH,
        "resources",
        "data",
        "channels.json"
    )

    with open(channels_file, "r", encoding="utf-8") as f:
        return json.load(f)


# ------------------------------------------------------------------
# Stream starten
# ------------------------------------------------------------------
def play_stream(handle, channel):

    channels = load_channels()

    if channel not in channels:

        xbmcgui.Dialog().notification(
            "WM2026",
            "Stream nicht gefunden",
            xbmcgui.NOTIFICATION_ERROR,
            3000
        )

        return

    stream_url = channels[channel]["dash"]

    list_item = xbmcgui.ListItem(path=stream_url)

    # DASH
    list_item.setMimeType("application/dash+xml")

    # InputStream Adaptive
    list_item.setProperty(
        "inputstream",
        "inputstream.adaptive"
    )

    list_item.setProperty(
        "inputstream.adaptive.manifest_type",
        "mpd"
    )

    xbmcplugin.setResolvedUrl(
        handle,
        True,
        list_item
    )