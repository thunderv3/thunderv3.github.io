# -*- coding: utf-8 -*-

import os
import json
import datetime
import time
import unicodedata

from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcvfs

from resources.lib.utils import is_match_live

# --------------------------------------------------------------
# Sportschau Parser
# --------------------------------------------------------------
from resources.lib.sportschau_parser import (
    update_broadcasts
)


ADDON_ID = "plugin.video.wm2026"

ADDON = xbmcaddon.Addon(id=ADDON_ID)

PROFILE_PATH = xbmcvfs.translatePath(
    ADDON.getAddonInfo("profile")
)

OPENFOOTBALL_URL = (
    "https://raw.githubusercontent.com/"
    "openfootball/worldcup.json/master/2026/worldcup.json"
)

CACHE_FILE = os.path.join(
    PROFILE_PATH,
    "matches_cache.json"
)

BROADCASTS_FILE = os.path.join(
    PROFILE_PATH,
    "broadcasts.json"
)

CACHE_DURATION = 43200

BROADCAST_CACHE_DURATION = 43200

_MATCH_CACHE = None


# ------------------------------------------------------------------
# Sonderzeichen normalisieren
# ------------------------------------------------------------------
def normalize_ascii(text):

    text = unicodedata.normalize(
        "NFKD",
        text
    )

    text = text.encode(
        "ascii",
        "ignore"
    ).decode(
        "ascii"
    )

    return text.strip()


# ------------------------------------------------------------------
# Profilordner erstellen
# ------------------------------------------------------------------
if not xbmcvfs.exists(PROFILE_PATH):

    xbmcvfs.mkdirs(PROFILE_PATH)


# ------------------------------------------------------------------
# Broadcast Cache prüfen
# ------------------------------------------------------------------
def is_broadcast_cache_valid():

    try:

        if not xbmcvfs.exists(BROADCASTS_FILE):

            return False

        modified_time = os.path.getmtime(
            BROADCASTS_FILE
        )

        age = time.time() - modified_time

        return age < BROADCAST_CACHE_DURATION

    except Exception as e:

        xbmc.log(
            f"[WM2026] Broadcast Cache Check Error: {e}",
            xbmc.LOGERROR
        )

        return False


# ------------------------------------------------------------------
# Senderdaten aktualisieren
# ------------------------------------------------------------------
def ensure_broadcasts():

    try:

        # ----------------------------------------------------------
        # Broadcast Cache verwenden
        # ----------------------------------------------------------
        if is_broadcast_cache_valid():

            xbmc.log(
                "[WM2026] Verwende Broadcast Cache",
                xbmc.LOGINFO
            )

            return

        xbmc.log(
            "[WM2026] Aktualisiere Sportschau Broadcasts",
            xbmc.LOGINFO
        )

        update_broadcasts()

    except Exception as e:

        xbmc.log(
            f"[WM2026] Broadcast Update Error: {e}",
            xbmc.LOGERROR
        )


# ------------------------------------------------------------------
# Senderzuordnung laden
# ------------------------------------------------------------------
def load_broadcasts():

    try:

        if not xbmcvfs.exists(BROADCASTS_FILE):

            xbmc.log(
                "[WM2026] Keine broadcasts.json gefunden",
                xbmc.LOGWARNING
            )

            return {}

        with xbmcvfs.File(
            BROADCASTS_FILE,
            "r"
        ) as f:

            data = f.read()

        broadcasts = json.loads(data)

        xbmc.log(
            f"[WM2026] {len(broadcasts)} "
            f"Broadcast Einträge geladen",
            xbmc.LOGINFO
        )

        return broadcasts

    except Exception as e:

        xbmc.log(
            f"[WM2026] Broadcast Error: {e}",
            xbmc.LOGERROR
        )

        return {}


# ------------------------------------------------------------------
# Cache laden
# ------------------------------------------------------------------
def load_cache():

    try:

        if not xbmcvfs.exists(CACHE_FILE):

            return None

        with xbmcvfs.File(
            CACHE_FILE,
            "r"
        ) as f:

            data = f.read()

        return json.loads(data)

    except Exception as e:

        xbmc.log(
            f"[WM2026] Cache Load Error: {e}",
            xbmc.LOGERROR
        )

        return None


# ------------------------------------------------------------------
# Cache speichern
# ------------------------------------------------------------------
def save_cache(data):

    try:

        with xbmcvfs.File(
            CACHE_FILE,
            "w"
        ) as f:

            f.write(
                json.dumps(
                    data,
                    ensure_ascii=False,
                    indent=2
                )
            )

        xbmc.log(
            "[WM2026] OpenFootball Cache gespeichert",
            xbmc.LOGINFO
        )

    except Exception as e:

        xbmc.log(
            f"[WM2026] Cache Save Error: {e}",
            xbmc.LOGERROR
        )


# ------------------------------------------------------------------
# Cache prüfen
# ------------------------------------------------------------------
def is_cache_valid():

    try:

        if not xbmcvfs.exists(CACHE_FILE):

            return False

        modified_time = os.path.getmtime(
            CACHE_FILE
        )

        age = time.time() - modified_time

        return age < CACHE_DURATION

    except Exception as e:

        xbmc.log(
            f"[WM2026] Cache Check Error: {e}",
            xbmc.LOGERROR
        )

        return False


# ------------------------------------------------------------------
# OpenFootball Daten laden
# ------------------------------------------------------------------
def load_openfootball_data():

    # --------------------------------------------------------------
    # Gültigen Cache verwenden
    # --------------------------------------------------------------
    if is_cache_valid():

        xbmc.log(
            "[WM2026] Verwende OpenFootball Cache",
            xbmc.LOGINFO
        )

        cached_data = load_cache()

        if cached_data:

            return cached_data

    # --------------------------------------------------------------
    # GitHub Abruf
    # --------------------------------------------------------------
    try:

        xbmc.log(
            "[WM2026] Lade OpenFootball Daten von GitHub",
            xbmc.LOGINFO
        )

        request = Request(
            OPENFOOTBALL_URL,
            headers={
                "User-Agent": "Mozilla/5.0"
            }
        )

        response = urlopen(
            request,
            timeout=10
        )

        data = response.read().decode(
            "utf-8"
        )

        json_data = json.loads(data)

        # ----------------------------------------------------------
        # Cache speichern
        # ----------------------------------------------------------
        save_cache(json_data)

        return json_data

    except Exception as e:

        xbmc.log(
            f"[WM2026] OpenFootball Error: {e}",
            xbmc.LOGERROR
        )

        # ----------------------------------------------------------
        # Fallback Cache
        # ----------------------------------------------------------
        cached_data = load_cache()

        if cached_data:

            xbmc.log(
                "[WM2026] Verwende alten Cache als Fallback",
                xbmc.LOGWARNING
            )

            return cached_data

        return {}


# ------------------------------------------------------------------
# Matchliste erstellen
# ------------------------------------------------------------------
def get_matches():

    global _MATCH_CACHE

    # --------------------------------------------------------------
    # Session Cache
    # --------------------------------------------------------------
    if _MATCH_CACHE is not None:

        xbmc.log(
            "[WM2026] Verwende Session Match Cache",
            xbmc.LOGINFO
        )

        return _MATCH_CACHE

    # --------------------------------------------------------------
    # Broadcasts aktualisieren
    # --------------------------------------------------------------
    ensure_broadcasts()

    data = load_openfootball_data()

    broadcasts = load_broadcasts()

    matches = []

    for match in data.get("matches", []):

        home = normalize_ascii(
            match.get(
                "team1",
                "Unbekannt"
            ).strip()
        )

        away = normalize_ascii(
            match.get(
                "team2",
                "Unbekannt"
            ).strip()
        )

        date = match.get(
            "date",
            ""
        ).strip()

        time = match.get(
            "time",
            ""
        )

        round_name = match.get(
            "round",
            ""
        )

        group_name = match.get(
            "group",
            ""
        )

        stadium = match.get(
            "ground",
            "Unbekannt"
        )

        # --------------------------------------------------------------
        # Match-Key
        # --------------------------------------------------------------
        key = f"{home}_{away}_{date}"

        xbmc.log(
            f"[WM2026] Match Key: {key}",
            xbmc.LOGINFO
        )

        # --------------------------------------------------------------
        # Senderzuordnung
        # --------------------------------------------------------------
        if key in broadcasts:

            channel = broadcasts[key]

            xbmc.log(
                f"[WM2026] Broadcast gefunden: "
                f"{key} -> {channel}",
                xbmc.LOGINFO
            )

        else:

            channel = "Magenta"

            xbmc.log(
                f"[WM2026] Kein Broadcast gefunden: "
                f"{key}",
                xbmc.LOGWARNING
            )

        # --------------------------------------------------------------
        # Nur ARD/ZDF spielbar
        # --------------------------------------------------------------
        playable = channel in [
            "ARD",
            "ZDF"
        ]

        matches.append({

            "home": home,

            "away": away,

            "date": date,

            "time": time,

            "stadium": stadium,

            "group": group_name,

            "round": round_name,

            "channel": channel,

            "playable": playable,

            "live": is_match_live(
                date,
                time
            )

        })

    # --------------------------------------------------------------
    # Nach Datum/Zeit sortieren
    # --------------------------------------------------------------
    matches.sort(
        key=lambda x: (
            x["date"],
            x["time"]
        )
    )

    # --------------------------------------------------------------
    # Session Cache speichern
    # --------------------------------------------------------------
    _MATCH_CACHE = matches

    xbmc.log(
        "[WM2026] Session Match Cache erstellt",
        xbmc.LOGINFO
    )

    return matches


# ------------------------------------------------------------------
# Spiele heute
# ------------------------------------------------------------------
def get_today_matches():

    today = datetime.datetime.now().strftime(
        "%Y-%m-%d"
    )

    matches = get_matches()

    return [
        match for match in matches
        if match["date"] == today
    ]


# ------------------------------------------------------------------
# LIVE Spiele
# ------------------------------------------------------------------
def get_live_matches():

    matches = get_matches()

    return [
        match for match in matches
        if match["live"]
    ]


# ------------------------------------------------------------------
# Deutschland Spiele
# ------------------------------------------------------------------
def get_germany_matches():

    matches = get_matches()

    return [
        match for match in matches
        if (
            "Germany" in match["home"]
            or
            "Germany" in match["away"]
        )
    ]


# ------------------------------------------------------------------
# Gruppenphase
# ------------------------------------------------------------------
def get_group_matches():

    matches = get_matches()

    return [
        match for match in matches
        if match["group"]
    ]


# ------------------------------------------------------------------
# Gruppenliste
# ------------------------------------------------------------------
def get_groups():

    matches = get_matches()

    groups = sorted(list(set(

        match["group"]

        for match in matches

        if match["group"]

    )))

    return groups


# ------------------------------------------------------------------
# Gruppenspiele
# ------------------------------------------------------------------
def get_matches_by_group(group_name):

    matches = get_matches()

    return [
        match for match in matches
        if match["group"] == group_name
    ]


# ------------------------------------------------------------------
# Runde filtern
# ------------------------------------------------------------------
def get_round_matches(round_name):

    matches = get_matches()

    return [
        match for match in matches
        if match["round"] == round_name
    ]


# ------------------------------------------------------------------
# Achtelfinale
# ------------------------------------------------------------------
def get_round_of_16_matches():

    return get_round_matches(
        "Round of 16"
    )


# ------------------------------------------------------------------
# Viertelfinale
# ------------------------------------------------------------------
def get_quarter_final_matches():

    return get_round_matches(
        "Quarter-finals"
    )


# ------------------------------------------------------------------
# Halbfinale
# ------------------------------------------------------------------
def get_semi_final_matches():

    return get_round_matches(
        "Semi-finals"
    )


# ------------------------------------------------------------------
# Spiel um Platz 3
# ------------------------------------------------------------------
def get_third_place_matches():

    return get_round_matches(
        "Third-place play-off"
    )


# ------------------------------------------------------------------
# Finale
# ------------------------------------------------------------------
def get_final_matches():

    return get_round_matches(
        "Final"
    )