# -*- coding: utf-8 -*-
# Python 3
# Primekiste.com - xStream Site Plugin
# API: /data/browse/ (Filmliste) + /data/watch/ (Streams)

from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger, cParser
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui
import json

SITE_IDENTIFIER = 'primekiste'
SITE_NAME = 'Primekiste'
SITE_ICON = 'primekiste.png'
SITE_FANART = cConfig().getAddonInfo('path') + '/resources/art/sites/' + SITE_ICON

# Global search deaktivieren falls gewünscht
if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'false':
    SITE_GLOBAL_SEARCH = False
    logger.info('-> [SitePlugin]: globalSearch for %s is deactivated.' % SITE_NAME)

# Domain Abfrage
DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'primekiste.com')
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER)

URL_MAIN   = 'https://' + DOMAIN
URL_BROWSE = URL_MAIN + '/data/browse/'
URL_WATCH  = URL_MAIN + '/data/watch/'
URL_LIST   = URL_BROWSE + '?lang=%s&type=%s&order_by=%s&page=%s'
URL_GENRE  = URL_BROWSE + '?lang=%s&type=%s&order_by=%s&genre=%s&page=%s'
URL_YEAR   = URL_BROWSE + '?lang=%s&type=%s&order_by=%s&year=%s&page=%s'
URL_CAST   = URL_BROWSE + '?lang=%s&type=%s&order_by=%s&cast=%s&page=%s'
URL_SEARCH_API = URL_BROWSE + '?lang=%s&keyword=%s&page=%s'

# Seitengroesse fuer Listenansicht
PAGE_SIZE = 16

SCRAPER_SETTINGS = f'''
            <group id="plugin_primekiste" label="30730">
                <setting id="plugin_primekiste" type="boolean" label="30050" help="30411">
                    <level>0</level>
                    <default>True</default>
                    <control type="toggle"/>
                </setting>
                <setting id="global_search_primekiste" type="boolean" label="30052">
                    <level>0</level>
                    <default>True</default>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_primekiste">false</dependency>
                    </dependencies>
                    <control type="toggle"/>
                </setting>
                <setting id="plugin_primekiste_checkDomain" type="boolean" label="30277">
                    <visible>false</visible>
                    <default>True</default>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_primekiste">false</dependency>
                        <dependency type="visible" operator="!is" setting="plugin_primekiste">false</dependency>
                    </dependencies>
                    <control type="toggle"/>
                </setting>
                <setting id="plugin_primekiste.domain" type="string" label="30278" help="">
                    <level>0</level>
                    <default>primekiste.com</default>
                    <constraints>
                        <allowempty>true</allowempty>
                    </constraints>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_primekiste">false</dependency>
                        <dependency type="visible" operator="!is" setting="plugin_primekiste">false</dependency>
                    </dependencies>
                    <control type="edit" format="string">
                        <heading>30278</heading>
                    </control>
                </setting>
                <setting id="plugin_primekiste_status" type="string" label="Dummy" help="">
                    <visible>false</visible>
                    <default>true</default>
                    <control type="toggle"/>
                </setting>
            </group>
'''


def _fetchJson(url, cacheTime=None):
    """JSON von der Primekiste-API holen."""
    oRequest = cRequestHandler(url, ignoreErrors=True)
    if cacheTime is not None:
        oRequest.cacheTime = cacheTime
    elif cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6
    oRequest.addHeaderEntry('Accept', 'application/json, text/plain, */*')
    oRequest.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
    oRequest.addHeaderEntry('Referer', URL_MAIN + '/')
    data = oRequest.request()
    if not data:
        return None
    try:
        return json.loads(data)
    except Exception:
        return None


def _fetchDesc(sId):
    """Beschreibung fuer einen Film/Serie aus Watch-API holen (langer Cache)."""
    try:
        obj = _fetchJson(URL_WATCH + '?_id=' + sId, cacheTime=60 * 60 * 24 * 7)
        if not obj:
            return ''
        aM = obj if isinstance(obj, dict) else {}
        if isinstance(aM.get('movie'), dict):
            aM = aM['movie']
        elif isinstance(aM.get('movies'), list) and aM['movies']:
            aM = aM['movies'][0]
        return str(aM.get('storyline') or aM.get('overview') or
                   aM.get('description') or aM.get('plot') or '')
    except Exception:
        return ''


def load():
    logger.info('Load %s' % SITE_NAME)
    params = ParameterHandler()
    sLanguage = cConfig().getSetting('prefLanguage')
    if sLanguage == '1':
        sLang = '2'
    elif sLanguage == '2':
        sLang = '3'
    else:
        sLang = 'all'
    params.setParam('sLanguage', sLang)

    # Filme
    params.setParam('sUrl', URL_LIST % (sLang, 'movies', 'new', '1'))
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30500), SITE_IDENTIFIER, 'showEntries'), params)   # Neues
    params.setParam('sUrl', URL_LIST % (sLang, 'movies', 'Trending', '1'))
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30502), SITE_IDENTIFIER, 'showEntries'), params)   # Filme Trending
    params.setParam('sUrl', URL_LIST % (sLang, 'movies', 'releases', '1'))
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30531), SITE_IDENTIFIER, 'showEntries'), params)   # Erscheinungsjahr

    # Serien
    params.setParam('sUrl', URL_LIST % (sLang, 'series', 'new', '1'))
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30511), SITE_IDENTIFIER, 'showEntries'), params)   # Serien Neu
    params.setParam('sUrl', URL_LIST % (sLang, 'series', 'Trending', '1'))
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30521), SITE_IDENTIFIER, 'showEntries'), params)   # Serien Trending

    # Genre Filme
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30551), SITE_IDENTIFIER, 'showGenreMMenu'), params)

    # Jahre
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30508), SITE_IDENTIFIER, 'showYearsMenu'), params)

    # Suche
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showSearch'), params)
    cGui().setEndOfDirectory()




def _showGenreMenu():
    params = ParameterHandler()
    sLang  = params.getValue('sLanguage') or 'all'
    sType  = params.getValue('sType')
    sOrder = params.getValue('sOrder') or 'new'
    genres = [
        'Action', 'Adventure', 'Animation', 'Biography', 'Comedy', 'Crime',
        'Documentary', 'Drama', 'Family', 'Fantasy', 'History', 'Horror',
        'Music', 'Mystery', 'Romance', 'Sci-Fi', 'Sport', 'Thriller', 'War', 'Western',
    ]
    for sGenre in genres:
        params.setParam('sUrl', URL_GENRE % (sLang, sType, sOrder, cParser.quotePlus(sGenre), '1'))
        cGui().addFolder(cGuiElement(sGenre, SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showGenreMMenu():
    params = ParameterHandler()
    params.setParam('sType', 'movies')
    for sOrder, sLabel in [('Trending','Trending'), ('new','Neu'), ('views','Meistgesehen'),
                            ('rating','Beste Bewertung'), ('votes','Meiste Votes'),
                            ('releases','Erscheinungsjahr'), ('name','Alphabetisch')]:
        params.setParam('sOrder', sOrder)
        cGui().addFolder(cGuiElement('Film-Genre: ' + sLabel, SITE_IDENTIFIER, '_showGenreMenu'), params)
    cGui().setEndOfDirectory()



def showYearsMenu():
    params = ParameterHandler()
    sLang = params.getValue('sLanguage') or 'all'
    import datetime
    current_year = datetime.datetime.now().year
    for year in range(current_year, 1929, -1):
        params.setParam('sUrl', URL_YEAR % (sLang, 'movies', 'new', str(year), '1'))
        cGui().addFolder(cGuiElement(str(year), SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not entryUrl:
        entryUrl = params.getValue('sUrl')

    # Aktuelle Seite aus URL lesen
    iPage = 1
    try:
        iPage = int(params.getValue('page')) or 1
    except Exception:
        pass

    # URL mit aktueller Seite aufbauen
    if 'page=' in entryUrl:
        import re
        sPageUrl = re.sub(r'page=\d+', 'page=%d' % iPage, entryUrl)
    else:
        sPageUrl = entryUrl + ('&' if '?' in entryUrl else '?') + 'page=%d' % iPage

    obj = _fetchJson(sPageUrl)
    if not obj:
        logger.info('[primekiste] showEntries: API gab None zurück für %s' % sPageUrl)
        if not sGui:
            try: oGui.showInfo()
            except Exception: pass
            try: oGui.setEndOfDirectory()
            except Exception: pass
        return

    # API gibt verschiedene Keys zurück - alle prüfen
    movies = (obj.get('movies') or obj.get('series') or obj.get('items') or
              obj.get('results') or obj.get('data') or [])
    if not isinstance(movies, list):
        movies = []

    logger.info('[primekiste] showEntries: %d Einträge für %s' % (len(movies), sPageUrl[-60:]))

    if not movies:
        if not sGui:
            try: oGui.showInfo()
            except Exception: pass
            try: oGui.setEndOfDirectory()
            except Exception: pass
        return

    # type=movies Filter - Serien nicht ausblenden
    if 'type=movies' in sPageUrl:
        movies = [m for m in movies if str(m.get('type', '')).lower() not in ('series', 'tvshow', 'show')]

    # Paginierung
    try:
        total_pages = int(obj.get('total_pages') or obj.get('totalPages') or 1)
    except Exception:
        total_pages = 1
    movies = movies[:PAGE_SIZE]
    total  = len(movies)

    for movie in movies:
        sId      = str(movie.get('_id', ''))
        sName    = str(movie.get('title', ''))
        sYear    = str(movie.get('year', ''))
        # Poster: verschiedene moegliche Keys
        sThumbnail = (movie.get('poster_path') or movie.get('poster') or
                      movie.get('poster_path_season') or movie.get('backdrop_path') or '')
        sThumbnail = str(sThumbnail)
        # Fanart: backdrop bevorzugt
        sFanartUrl = (movie.get('backdrop_path') or movie.get('poster_path') or
                      movie.get('poster') or '')
        sFanartUrl = str(sFanartUrl)
        # Beschreibung: verschiedene moegliche Keys
        sDesc    = (movie.get('storyline') or movie.get('overview') or
                    movie.get('description') or movie.get('plot') or '')
        sDesc    = str(sDesc)
        sQuality = str(movie.get('quality') or '')
        sImdb    = str(movie.get('imdb_id', ''))
        # Serien-Erkennung: API-Typ, URL-Kontext, oder 'Staffel'/'Season' im Titel
        sType = str(movie.get('type', '')).lower()
        sTitle_lower = sName.lower()
        isTvshow = (sType in ('series', 'tvseries', 'tvshow', 'tv', 'show') or
                    'type=series' in sPageUrl or
                    'staffel' in sTitle_lower or 'season' in sTitle_lower)

        if not sId or not sName:
            continue
        if sSearchText and not cParser.search(sSearchText, sName):
            continue

        # Thumbnail-URL vervollstaendigen
        if sThumbnail and not sThumbnail.startswith('http'):
            sThumbnail = 'https://image.tmdb.org/t/p/w300' + sThumbnail
        if sFanartUrl and not sFanartUrl.startswith('http'):
            sFanartUrl = 'https://image.tmdb.org/t/p/w300' + sFanartUrl

        # Titelformat: Name - (Jahr) [Qualität]
        sDisplayTitle = sName.strip()
        if sYear and len(sYear) == 4:
            sDisplayTitle += ' - (%s)' % sYear
        if sQuality and sQuality.strip():
            sDisplayTitle += ' [%s]' % sQuality.strip()
        oGuiElement = cGuiElement(sDisplayTitle, SITE_IDENTIFIER, 'showSeasons' if isTvshow else 'showHosters')
        oGuiElement.setMediaType('tvshow' if isTvshow else 'movie')
        if sThumbnail:
            oGuiElement.setThumbnail(sThumbnail)
        if sFanartUrl:
            oGuiElement.setFanart(sFanartUrl)
        if sYear and len(sYear) == 4:
            oGuiElement.setYear(sYear)
        if not sDesc:
            try:
                sDesc = _fetchDesc(sId)
            except Exception:
                sDesc = ''
        if sDesc:
            try:
                oGuiElement.setDescription(sDesc)
            except Exception:
                pass

        params.setParam('sId',        sId)
        params.setParam('sName',      sName)
        params.setParam('sThumbnail', sThumbnail)
        params.setParam('sImdb',      sImdb)
        params.setParam('sDesc',      sDesc[:200] if sDesc else '')  # für showSeasons/showEpisodes
        oGui.addFolder(oGuiElement, params, isTvshow, total)

    if not sGui and not sSearchText:
        try:
            if iPage < total_pages:
                params.setParam('page', iPage + 1)
                params.setParam('sUrl', entryUrl)
                oGui.addNextPage(SITE_IDENTIFIER, 'showEntries', params)
        except Exception:
            pass
        # setView URL-basiert
        if 'type=series' in sPageUrl:
            oGui.setView('tvshows')
        elif 'type=movies' in sPageUrl:
            oGui.setView('movies')
        else:
            oGui.setView('tvshows' if isTvshow else 'movies')
        oGui.setEndOfDirectory()


def showSeasons():
    """Staffeln einer Serie anzeigen."""
    params     = ParameterHandler()
    sId        = params.getValue('sId')
    sThumbnail = params.getValue('sThumbnail')
    sDesc      = params.getValue('sDesc') if params.getValue('sDesc') else ''

    obj = _fetchJson(URL_WATCH + '?_id=' + sId)
    if not obj:
        logger.info('[primekiste] showSeasons: Watch-API blocked/None für sId=%s' % sId)
        # Cloudflare blockt → direkt showHosters versuchen
        try:
            hosters = showHosters()
        except Exception:
            hosters = None
        if not hosters:
            try: cGui().showInfo()
            except Exception: pass
            try: cGui().setEndOfDirectory()
            except Exception: pass
        return

    streams = obj.get('streams', [])
    # Alle vorhandenen Staffeln ermitteln
    seasons = sorted(set(
        str(s.get('s', '1')) for s in streams if s.get('s') is not None
    ), key=lambda x: int(x) if x.isdigit() else 0)

    if not seasons:
        # Keine Staffelinfo → direkt Hoster zeigen
        try:
            showHosters()
        except Exception:
            pass
        return

    total = len(seasons)
    for sSeason in seasons:
        oGuiElement = cGuiElement('Staffel ' + sSeason, SITE_IDENTIFIER, 'showEpisodes')
        oGuiElement.setMediaType('season')
        if sThumbnail:
            oGuiElement.setThumbnail(sThumbnail)
        if sDesc:
            oGuiElement.setDescription(sDesc)
        params.setParam('season', sSeason)
        cGui().addFolder(oGuiElement, params, True, total)
    cGui().setView('seasons')
    cGui().setEndOfDirectory()


def showEpisodes():
    """Episoden einer Staffel anzeigen."""
    params     = ParameterHandler()
    sId        = params.getValue('sId')
    sSeason    = params.getValue('season')
    sThumbnail = params.getValue('sThumbnail')
    sDesc      = params.getValue('sDesc') if params.getValue('sDesc') else ''

    obj = _fetchJson(URL_WATCH + '?_id=' + sId)
    if not obj:
        logger.info('[primekiste] showEpisodes: Watch-API blocked/None für sId=%s' % sId)
        try: cGui().showInfo()
        except Exception: pass
        try: cGui().setEndOfDirectory()
        except Exception: pass
        return

    streams = obj.get('streams', [])
    # Alle Episoden der gewählten Staffel
    episodes = sorted(set(
        str(s.get('e', '1')) for s in streams
        if str(s.get('s', '1')) == sSeason and s.get('e') is not None
    ), key=lambda x: int(x) if x.isdigit() else 0)

    if not episodes:
        cGui().showInfo()
        return

    total = len(episodes)
    for sEpisode in episodes:
        oGuiElement = cGuiElement('Episode ' + sEpisode, SITE_IDENTIFIER, 'showEpisodeHosters')
        oGuiElement.setMediaType('episode')
        if sThumbnail:
            oGuiElement.setThumbnail(sThumbnail)
        if sDesc:
            oGuiElement.setDescription(sDesc)
        params.setParam('episode', sEpisode)
        cGui().addFolder(oGuiElement, params, False, total)
    cGui().setView('episodes')
    cGui().setEndOfDirectory()


def _buildHosters(streams):
    """Stream-Liste in xStream-Hoster-Format umwandeln."""
    hosters = []
    _skip = ('veev.to', 'veevcdn', 'vide0.net', 'vidsonic.net',
             'vidara.to', 'vidara.so', 'vidara.si',
             'vinovo.to', 'vinovo.si', 'bonuscaf.com', 'playmogo.com')

    for stream in streams:
        sUrl = stream.get('stream', '')
        if not sUrl:
            continue
        if any(x in sUrl for x in ('filmpalast', 'primekiste', DOMAIN)):
            continue
        if any(x in sUrl for x in _skip):
            continue
        if sUrl.startswith('//'):
            sUrl = 'https:' + sUrl
        sRelease = stream.get('release', '')
        sQuality = _quality(sRelease)
        sName = cParser.urlparse(sUrl).split('.')[0].strip() if sUrl else ''
        if cConfig().isBlockedHoster(sName)[0]:
            continue
        hoster = {
            'link': sUrl,
            'name': sName,
            'displayedName': '%s [I][%s][/I]' % (sName, sQuality),
            'quality': sQuality
        }
        hosters.append(hoster)
    return hosters


def _quality(release):
    r = str(release).upper()
    if '4K' in r or '2160' in r:
        return '4K'
    if '1080' in r:
        return '1080p'
    if '720' in r:
        return '720p'
    if '.TS.' in r or '.CAM.' in r or 'TELESYNC' in r:
        return 'CAM'
    if 'SD' in r or '480' in r:
        return 'SD'
    return 'HD'


def showHosters():
    """Stream-Links für einen Film anzeigen."""
    hosters = []
    params  = ParameterHandler()
    sId     = params.getValue('sId')

    obj = _fetchJson(URL_WATCH + '?_id=' + sId)
    if not obj:
        logger.info('[primekiste] showHosters: Watch-API blocked/None für sId=%s' % sId)
    if obj:
        streams = obj.get('streams', [])
        hosters = _buildHosters(streams)

    if hosters:
        hosters.append('getHosterUrl')
    return hosters


def showEpisodeHosters():
    """Stream-Links für eine Episode anzeigen."""
    hosters  = []
    params   = ParameterHandler()
    sId      = params.getValue('sId')
    sSeason  = params.getValue('season')
    sEpisode = params.getValue('episode')

    obj = _fetchJson(URL_WATCH + '?_id=' + sId)
    if not obj:
        logger.info('[primekiste] showHosters: Watch-API blocked/None für sId=%s' % sId)
    if obj:
        streams = [s for s in obj.get('streams', [])
                   if str(s.get('s', '')) == sSeason and str(s.get('e', '')) == sEpisode]
        hosters = _buildHosters(streams)

    if hosters:
        hosters.append('getHosterUrl')
    return hosters


def getHosterUrl(sUrl=False):
    return [{'streamUrl': sUrl, 'resolved': False}]


def showSearch():
    sSearchText = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
    if not sSearchText:
        return
    _search(False, sSearchText)
    cGui().setEndOfDirectory()



def _search(oGui, sSearchText):
    params = ParameterHandler()
    sLang = params.getValue('sLanguage') or 'all'
    sUrl = URL_SEARCH_API % (sLang, cParser.quotePlus(sSearchText), '1')
    showEntries(sUrl, oGui, sSearchText)
