# -*- coding: utf-8 -*-
# Python 3
# FilmPalast.one - xStream Site Plugin
# HTML-Struktur identisch zu topstreamfilm.live

from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger, cParser
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui
import html as _html

SITE_IDENTIFIER = 'filmpro'
SITE_NAME = 'FilmPro'
SITE_ICON = 'filmpro.png'
SITE_FANART = cConfig().getAddonInfo('path') + '/resources/art/sites/' + SITE_ICON

# Global search function is thus deactivated!
if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'false':
    SITE_GLOBAL_SEARCH = False
    logger.info('-> [SitePlugin]: globalSearch for %s is deactivated.' % SITE_NAME)

# Domain Abfrage
DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'filmpalast.one')
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER)

URL_MAIN   = 'https://' + DOMAIN
URL_NEW    = URL_MAIN + '/'
URL_MOVIES = URL_MAIN + '/filme/'
URL_KINO   = URL_MAIN + '/kinofilme/'
URL_SERIES = URL_MAIN + '/serien/'
URL_SOON   = URL_MAIN + '/demnachst/'
URL_SEARCH = URL_MAIN + '/?story=%s&do=search&subaction=search'

SCRAPER_SETTINGS = f'''
            <group id="filmpro" label="30729">
                <setting id="plugin_filmpro" type="boolean" label="30050" help="30411">
                    <level>0</level>
                    <default>True</default>
                    <control type="toggle"/>
                </setting>
                <setting id="global_search_filmpro" type="boolean" label="30052">
                    <level>0</level>
                    <default>True</default>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_filmpro">false</dependency>
                    </dependencies>
                    <control type="toggle"/>
                </setting>
                <setting id="plugin_filmpro_checkDomain" type="boolean" label="30277">
                    <visible>false</visible>
                    <default>True</default>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_filmpro">false</dependency>
                        <dependency type="visible" operator="!is" setting="plugin_filmpro">false</dependency>
                    </dependencies>
                    <control type="toggle"/>
                </setting>
                <setting id="plugin_filmpro.domain" type="string" label="30278" help="">
                    <level>0</level>
                    <default>filmpalast.one</default>
                    <constraints>
                        <allowempty>true</allowempty>
                    </constraints>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_filmpro">false</dependency>
                        <dependency type="visible" operator="!is" setting="plugin_filmpro">false</dependency>
                    </dependencies>
                    <control type="edit" format="string">
                        <heading>30278</heading>
                    </control>
                </setting>
                <setting id="plugin_filmpro_status" type="string" label="Dummy" help="">
                    <visible>false</visible>
                    <default>true</default>
                    <control type="toggle"/>
                </setting>
            </group>
'''


def load():
    logger.info('Load %s' % SITE_NAME)
    params = ParameterHandler()
    params.setParam('sUrl', URL_NEW)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30500), SITE_IDENTIFIER, 'showEntries'), params)  # Neues
    params.setParam('sUrl', URL_KINO)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30501), SITE_IDENTIFIER, 'showEntries'), params)  # Aktuelle Filme im Kino
    params.setParam('sUrl', URL_MOVIES)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30502), SITE_IDENTIFIER, 'showEntries'), params)  # Filme
    params.setParam('sUrl', URL_SERIES)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30511), SITE_IDENTIFIER, 'showEntries'), params)  # Serien
    params.setParam('sUrl', URL_SOON)
    cGui().addFolder(cGuiElement('Demnächst im Kino', SITE_IDENTIFIER, 'showEntries'), params)                 # Demnächst
    params.setParam('sUrl', URL_MAIN)
    cGui().addFolder(cGuiElement('Erscheinungsjahr', SITE_IDENTIFIER, 'showYears'), params)                    # Jahre
    params.setParam('Value', 'KATEGORIEN')
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30506), SITE_IDENTIFIER, 'showGenre'), params)   # Genre
    params.setParam('Value', 'LAND')
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30538), SITE_IDENTIFIER, 'showCountry'), params) # Land
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showSearch'), params)  # Suche
    cGui().setEndOfDirectory()


def showGenre():
    params = ParameterHandler()
    # Genre-Liste aus dem HTML der Seite (KATEGORIEN)
    genres = [
        ('Drama', URL_MAIN + '/drama/'),
        ('Serien', URL_MAIN + '/serien/'),
        ('Familie', URL_MAIN + '/familie/'),
        ('Fantasy', URL_MAIN + '/fantasy/'),
        ('Historie', URL_MAIN + '/historie/'),
        ('Horror', URL_MAIN + '/horror/'),
        ('Musik', URL_MAIN + '/musik/'),
        ('Mystery', URL_MAIN + '/mystery/'),
        ('Romantik', URL_MAIN + '/romantik/'),
        ('Reality-TV', URL_MAIN + '/reality-tv/'),
        ('Sci-Fi', URL_MAIN + '/sci-fi/'),
        ('Sport', URL_MAIN + '/sport/'),
        ('Thriller', URL_MAIN + '/thriller/'),
        ('Krieg', URL_MAIN + '/krieg/'),
        ('Western', URL_MAIN + '/western/'),
        ('Action', URL_MAIN + '/action/'),
        ('Abenteuer', URL_MAIN + '/abenteuer/'),
        ('Animation', URL_MAIN + '/animation/'),
        ('Biographie', URL_MAIN + '/biographie/'),
        ('Komödie', URL_MAIN + '/komodie/'),
        ('Krimi', URL_MAIN + '/krimi/'),
        ('Dokumentation', URL_MAIN + '/dokumentation/'),
        ('Demnächst', URL_MAIN + '/demnachst/'),
        ('Liebesfilm', URL_MAIN + '/liebesfilm/'),
        ('Kinofilme', URL_MAIN + '/kinofilme/'),
    ]
    for sName, sUrl in genres:
        params.setParam('sUrl', sUrl)
        cGui().addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showCountry():
    params = ParameterHandler()
    # Länder aus dem HTML der Seite
    countries = [
        ('USA', URL_MAIN + '/xfsearch/USA'),
        ('Deutschland', URL_MAIN + '/xfsearch/deutschland'),
        ('Kanada', URL_MAIN + '/xfsearch/country/Canada/'),
        ('Italien', URL_MAIN + '/xfsearch/country/italien/'),
        ('Frankreich', URL_MAIN + '/xfsearch/country/frankreich/'),
        ('Spanien', URL_MAIN + '/xfsearch/country/spanien/'),
        ('China', URL_MAIN + '/xfsearch/country/China/'),
        ('Japan', URL_MAIN + '/xfsearch/country/Japan/'),
        ('Taiwan', URL_MAIN + '/xfsearch/country/Taiwan/'),
        ('Thailand', URL_MAIN + '/xfsearch/country/Thailand/'),
        ('Belgium', URL_MAIN + '/xfsearch/country/Belgium/'),
        ('Israel', URL_MAIN + '/xfsearch/country/Israel/'),
    ]
    for sName, sUrl in countries:
        params.setParam('sUrl', sUrl)
        cGui().addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showYears():
    params = ParameterHandler()
    import datetime
    current_year = datetime.datetime.now().year
    for year in range(current_year, 1989, -1):
        sUrl = URL_MAIN + '/xfsearch/%d' % year
        params.setParam('sUrl', sUrl)
        cGui().addFolder(cGuiElement(str(year), SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=False, sSearchPageText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    isTvshow = False
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6  # 6 Stunden
    sHtmlContent = oRequest.request()

    # Erfasst href, data-src (Thumbnail), Titel und den TPMvCn-Block mit allen Infos
    pattern = 'TPostMv">.*?href="([^"]+).*?data-src="([^"]+).*?<h3[^>]*>([^<]+).*?TPMvCn(.*?)</li>'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch:
        if not sGui: oGui.showInfo()
        return

    # Jahresfilter wenn URL ein xfsearch-Jahr enthält
    import re as _re
    _year_match = _re.search(r'/xfsearch/(\d{4})', entryUrl if entryUrl else '')
    if _year_match:
        _yf = _year_match.group(1)
        aResult = [r for r in aResult if _yf in r[3]][:16]
    else:
        aResult = aResult[:16]
    total = len(aResult)

    for sUrl, sThumbnail, sName, sDummy in aResult:
        sName = _html.unescape(sName).strip()
        if sSearchText and not cParser.search(sSearchText, sName):
            continue

        isYear,     sYear     = cParser.parseSingleResult(sDummy, 'Date[^>]*>([0-9]+)</span>')
        isDuration, sDuration = cParser.parseSingleResult(sDummy, 'Time[^>]*>([0-9]+)')
        isRating,   sRating   = cParser.parseSingleResult(sDummy, 'Vote[^>]*>([0-9.]+)')
        isQuality,  sQuality  = cParser.parseSingleResult(sDummy, 'Qlty">([^<]+)</span>')
        isDesc,     sDesc     = cParser.parseSingleResult(sDummy, 'Description[^>]*>\\s*<p>([^<]+)')

        # TV-Show Erkennung: erstmal False, wird nach Detail-Request korrigiert
        try:
            isTvshow = int(sDuration) <= 70 if isDuration else False
        except Exception:
            isTvshow = False

        if sThumbnail.startswith('/'):
            sThumbnail = URL_MAIN + sThumbnail

        # Seitentitel bereinigen: " - Der Film", " - Die Serie" usw. entfernen
        import re as _re
        sCleanName = _re.sub(r'\s*-\s*(Der|Die|Das|The)\s+Film.*$', '', sName, flags=_re.IGNORECASE).strip()
        sCleanName = _re.sub(r'\s*-\s*(Der|Die|Das|The)\s+Serie.*$', '', sCleanName, flags=_re.IGNORECASE).strip()
        # Titel zusammenbauen: Name - (Jahr) [Qualität]
        sTitle = sCleanName
        if isYear:
            sTitle += ' - (%s)' % sYear
        if isQuality:
            sTitle += ' [%s]' % sQuality.strip()
        oGuiElement = cGuiElement(sTitle, SITE_IDENTIFIER, 'showSeasons' if isTvshow else 'showHosters')
        oGuiElement.setMediaType('tvshow' if isTvshow else 'movie')
        oGuiElement.setThumbnail(sThumbnail)
        if isYear:
            oGuiElement.setYear(sYear)
        if isDuration:
            oGuiElement.addItemValue('duration', sDuration)
        if isRating:
            oGuiElement.addItemValue('rating', sRating)
        if isDesc:
            oGuiElement.setDescription(sDesc.strip())

        # Detail-Request für Fanart UND Genre-Erkennung (gecacht)
        try:
            sDetailUrl = sUrl if sUrl.startswith('http') else URL_MAIN + sUrl
            sDetailHtml = cRequestHandler(sDetailUrl, caching=True, ignoreErrors=True).request()
            if sDetailHtml:
                # Fanart
                isFanart, sFanart = cParser.parseSingleResult(sDetailHtml, 'TPostBg[^>]*data-src="([^"]+)"')
                if not isFanart:
                    isFanart, sFanart = cParser.parseSingleResult(sDetailHtml, 'property="og:image"[^>]*content="([^"]+)"')
                if isFanart:
                    if sFanart.startswith('/'):
                        sFanart = URL_MAIN + sFanart
                    if sFanart.startswith('http'):
                        # .webp oft nicht vorhanden → auf .jpg umschreiben
                        sFanart = sFanart.replace('.webp', '.jpg')
                        oGuiElement.setFanart(sFanart)
                # Genre-basierte Serien-Erkennung (zuverlässiger als Laufzeit)
                # Aus Detail-HTML: <a href=".../serien/">Serien</a>
                isGenre, sGenre = cParser.parseSingleResult(sDetailHtml, r'Genre.*?</strong>(.*?)</li>')
                if isGenre and '/serien/' in sGenre.lower():
                    isTvshow = True
                    oGuiElement.setFunction('showSeasons')
                    oGuiElement.setMediaType('tvshow')
                elif isGenre:
                    isTvshow = False
                    oGuiElement.setFunction('showHosters')
                    oGuiElement.setMediaType('movie')
        except Exception:
            pass

        params.setParam('entryUrl', sUrl)
        params.setParam('sName', sName)
        params.setParam('sThumbnail', sThumbnail)
        params.setParam('sDesc', sDesc if isDesc else '')
        oGui.addFolder(oGuiElement, params, isTvshow, total)

    if not sGui and not sSearchText and not sSearchPageText:
        isMatchNextPage, sNextUrl = cParser.parseSingleResult(sHtmlContent, 'href="([^"]+)">Next')
        isMatchSiteSearch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, 'class="wp-pagenavi">(.*?)Next')
        if isMatchSiteSearch:
            isMatch, aResult = cParser.parse(sHtmlContainer,
                '<span>([0-9]+)</span>.*?nav_ext">.*?">([0-9]+)</a>.*?href="([^"]+)')
            for sPageActive, sPageLast, sNextPage in (aResult or []):
                sPageName = (cConfig().getLocalizedString(30284) + str(sPageActive) +
                             cConfig().getLocalizedString(30285) + str(sPageLast) +
                             cConfig().getLocalizedString(30286))
                params.setParam('sNextPage', sNextPage)
                params.setParam('sPageLast', sPageLast)
                oGui.searchNextPage(sPageName, SITE_IDENTIFIER, 'showSearchPage', params)
        if isMatchNextPage:
            params.setParam('sUrl', sNextUrl)
            oGui.addNextPage(SITE_IDENTIFIER, 'showEntries', params)
        oGui.setView('tvshows' if isTvshow else 'movies')
        oGui.setEndOfDirectory()


def showSeasons():
    params     = ParameterHandler()
    sUrl       = params.getValue('entryUrl')
    sThumbnail = params.getValue('sThumbnail')
    sDesc      = params.getValue('sDesc')
    oRequest   = cRequestHandler(sUrl)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6
    sHtmlContent = oRequest.request()

    # IMDB-ID aus Detailseite → meinecloud Playerseite für Staffelnummern
    isImdb, sImdbId = cParser.parseSingleResult(sHtmlContent, r"var imdb\s*=\s*'(tt(\d+))'")
    isId, sShowId = cParser.parseSingleResult(sHtmlContent, r'var show_id\s*=\s*(\d+)')

    aSeasonNums = []
    sImdbNum = ''

    if isImdb and sImdbId:
        sImdbNum = sImdbId.replace('tt', '')
        # meinecloud Playerseite lädt Staffel-Sidebar mit echten Nummern (S1, S2...)
        sMcUrl = 'https://meinecloud.click/serial/%s?s=1&e=1' % sImdbNum
        sMcHtml = cRequestHandler(sMcUrl, caching=True).request() or ''
        # Staffelnummern aus Sidebar-Tabs: <div class="_stab...">S1</div>
        isS, aLabels = cParser.parse(sMcHtml, r'_stab[^>]*>\s*S(\d+)\s*<')
        if isS and aLabels:
            aSeasonNums = aLabels
        else:
            # Fallback: Anzahl data-season Attribute → 1-basiert nummerieren
            isS2, aIds = cParser.parse(sMcHtml, r'data-season=["\']?(\d+)["\']?')
            aSeasonNums = [str(i+1) for i in range(len(aIds))] if (isS2 and aIds) else []

    if not aSeasonNums:
        # DLE Ajax Fallback
        if isId:
            sAjaxUrl = URL_MAIN + '/engine/ajax/controller.php?mod=getSerials&news_id=' + sShowId + '&action=getSeasons'
            sAjaxHtml = cRequestHandler(sAjaxUrl, caching=True).request() or ''
            isS3, aIds3 = cParser.parse(sAjaxHtml, r'data-season=["\']?(\d+)["\']?')
            aSeasonNums = [str(i+1) for i in range(len(aIds3))] if (isS3 and aIds3) else ['1']
        else:
            aSeasonNums = ['1']

    seen = set()
    aSeasonNums = [x for x in aSeasonNums if not (x in seen or seen.add(x))]
    params.setParam('sShowId', sShowId or '')
    params.setParam('sImdbNum', sImdbNum)
    total = len(aSeasonNums)
    for sSeason in aSeasonNums:
        oGuiElement = cGuiElement('Staffel ' + sSeason, SITE_IDENTIFIER, 'showEpisodes')
        oGuiElement.setSeason(sSeason)
        oGuiElement.setMediaType('season')
        oGuiElement.setThumbnail(sThumbnail)
        if sDesc:
            oGuiElement.setDescription(sDesc)
        cGui().addFolder(oGuiElement, params, True, total)
    cGui().setView('seasons')
    cGui().setEndOfDirectory()


def showEpisodes():
    params     = ParameterHandler()
    entryUrl   = params.getValue('entryUrl')
    sThumbnail = params.getValue('sThumbnail')
    sSeason    = params.getValue('season')
    sShowId    = params.getValue('sShowId')
    sDesc      = params.getValue('sDesc')

    # sImdbNum aus params (von showSeasons weitergegeben)
    sImdbNum = params.getValue('sImdbNum')

    aEpNums = []

    # Methode 1: meinecloud Playerseite - enthält alle Episoden der Staffel als data-link
    if sImdbNum:
        sMcUrl = 'https://meinecloud.click/serial/%s?s=%s&e=1' % (sImdbNum, sSeason)
        sMcHtml = cRequestHandler(sMcUrl, caching=True).request() or ''
        # Episodentitel aus Sidebar: <div class="_ep-t">Schulanfang</div> pro Episode
        isEpT, aEpTitles = cParser.parse(sMcHtml, r'_ep-t[^>]*>([^<]+)<')
        isLinks, aLinks = cParser.parse(sMcHtml, r'data-link=["\']([^"\'>]+)["\']')
        if isLinks and aLinks:
            aEpNums = [str(i+1) for i in range(len(aLinks))]

    # Methode 2: DLE Ajax Fallback
    if not aEpNums and sShowId:
        sAjaxUrl = URL_MAIN + '/engine/ajax/controller.php?mod=getSerials&news_id=' + sShowId + '&season=' + sSeason + '&action=getEpisodes'
        sAjaxHtml = cRequestHandler(sAjaxUrl, caching=True).request() or ''
        isM2, aR2 = cParser.parse(sAjaxHtml, r'data-episode=["\']?(\d+)["\']?')
        if isM2 and aR2:
            aEpNums = aR2

    if not aEpNums:
        aEpNums = ['1']

    seen = set()
    aEpNums = [x for x in aEpNums if not (x in seen or seen.add(x))]
    total = len(aEpNums)
    for i, sEpisode in enumerate(aEpNums):
        # Episodentitel wenn vorhanden
        sEpTitle = 'Episode ' + sEpisode
        try:
            if aEpTitles and i < len(aEpTitles):
                sEpTitle = 'E%s — %s' % (sEpisode, aEpTitles[i].strip())
        except Exception:
            pass
        oGuiElement = cGuiElement(sEpTitle, SITE_IDENTIFIER, 'showEpisodeHosters')
        oGuiElement.setThumbnail(sThumbnail)
        if sDesc:
            oGuiElement.setDescription(sDesc)
        oGuiElement.setMediaType('episode')
        params.setParam('entryUrl', entryUrl)
        params.setParam('sShowId', sShowId)
        params.setParam('sImdbNum', sImdbNum)
        params.setParam('season', sSeason)
        params.setParam('episode', sEpisode)
        cGui().addFolder(oGuiElement, params, False, total)
    cGui().setView('episodes')
    cGui().setEndOfDirectory()


def showEpisodeHosters():
    hosters  = []
    params   = ParameterHandler()
    sUrl     = params.getValue('entryUrl')
    sSeason  = params.getValue('season')
    sEpisode = params.getValue('episode')
    sQuality = '720'

    # IMDB-ID aus gecachter Detailseite holen
    sHtmlContent = cRequestHandler(sUrl, caching=True).request() or ''
    isImdb, sImdbId = cParser.parseSingleResult(sHtmlContent, r"var imdb\s*=\s*'(tt(\d+))'")

    if isImdb and sImdbId:
        # IMDB-Nummer (ohne 'tt') für meinecloud URL
        sImdbNum = sImdbId.replace('tt', '')

        # meinecloud Playerseite mit Season+Episode direkt laden
        # Format: https://meinecloud.click/serial/IMDBNUM?s=S&e=E
        sMcPlayerUrl = 'https://meinecloud.click/serial/%s?s=%s&e=%s' % (sImdbNum, sSeason, sEpisode)
        sMcHtml = cRequestHandler(sMcPlayerUrl, caching=False).request() or ''

        if sMcHtml:
            # Alle data-links aus der Playerseite holen (Episode 1, 2, 3...)
            isLinks, aLinks = cParser.parse(sMcHtml, r'data-link=["\']([^"\'>]+)["\']')
            if isLinks and aLinks:
                try:
                    idx = int(sEpisode) - 1
                    sDataLink = aLinks[idx] if idx < len(aLinks) else aLinks[0]
                except Exception:
                    sDataLink = aLinks[0]
                if sDataLink:
                    if sDataLink.startswith('//'):
                        sDataLink = 'https:' + sDataLink
                    sName = cParser.urlparse(sDataLink).split('.')[0].strip() or 'dr0pstream'
                    hoster = {'link': sDataLink, 'name': sName,
                              'displayedName': '%s [I][%sp][/I]' % (sName, sQuality),
                              'quality': sQuality}
                    hosters.append(hoster)

        # Fallback: check-API für player_url
        if not hosters:
            sMcCheckUrl = 'https://meinecloud.click/serials.php?task=check&id_imdb=' + sImdbId
            sMcCheck = cRequestHandler(sMcCheckUrl, caching=False).request() or ''
            isUrl2, sPlayer2 = cParser.parseSingleResult(sMcCheck, r'"player_url"\s*:\s*"([^"]+)"')
            if isUrl2 and sPlayer2:
                sPlayer2 = sPlayer2.replace('\/', '/')
                sep = '&' if '?' in sPlayer2 else '?'
                sPlayer2 = sPlayer2 + sep + 's=%s&e=%s' % (sSeason, sEpisode)
                hoster = {'link': sPlayer2, 'name': 'meinecloud',
                          'displayedName': 'meinecloud [I][%sp][/I]' % sQuality,
                          'quality': sQuality}
                hosters.append(hoster)

    if hosters:
        hosters.append('getHosterUrl')
    return hosters


def showHosters():
    hosters = []
    params  = ParameterHandler()
    sUrl    = params.getValue('entryUrl')
    sHtmlContent = cRequestHandler(sUrl, caching=False).request()
    pattern = '<iframe[^>]*src="([^"]+)"'
    isMatch, hUrl = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatch:
        sHtmlContainer = cRequestHandler(hUrl).request()
        isMatch, aResult = cParser.parse(sHtmlContainer, 'data-link="([^"]+)')
        if isMatch:
            sQuality = '720'
            for sUrl in aResult:
                if 'youtube' in sUrl:
                    continue
                if sUrl.startswith('//'):
                    sUrl = 'https:' + sUrl
                sName = cParser.urlparse(sUrl).split('.')[0].strip()
                if cConfig().isBlockedHoster(sName)[0]: continue
                hoster = {'link': sUrl, 'name': sName,
                          'displayedName': '%s [I][%sp][/I]' % (sName, sQuality),
                          'quality': sQuality}
                hosters.append(hoster)
    if hosters:
        hosters.append('getHosterUrl')
    return hosters


def getHosterUrl(sUrl=False):
    # dr0pstream und ähnliche: direkt resolved=False → resolveUrl übernimmt
    # meinecloud serial Seite: m3u8/mp4 extrahieren
    if sUrl and 'meinecloud.click/serial' in sUrl:
        try:
            sHtml = cRequestHandler(sUrl, caching=False).request() or ''
            for pat in [
                r'["\'](https?://[^"\']+\.m3u8[^"\']*)["\'\s]',
                r'["\'](https?://[^"\']+\.mp4[^"\']*)["\'\s]',
                r'file\s*:\s*["\'](https?://[^"\']+)["\'\s]',
            ]:
                isM, aR = cParser.parse(sHtml, pat)
                if isM and aR:
                    return [{'streamUrl': aR[0], 'resolved': True}]
        except Exception:
            pass
    return [{'streamUrl': sUrl, 'resolved': False}]


def showSearch():
    sSearchText = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
    if not sSearchText: return
    _search(False, sSearchText)
    cGui().setEndOfDirectory()


def _search(oGui, sSearchText):
    showEntries(URL_SEARCH % cParser.quotePlus(sSearchText), oGui, sSearchText)


def showSearchPage():
    params          = ParameterHandler()
    sNextPage       = params.getValue('sNextPage')
    sPageLast       = params.getValue('sPageLast')
    sHeading        = cConfig().getLocalizedString(30282) + str(sPageLast)
    sSearchPageText = cGui().showKeyBoard(sHeading=sHeading)
    if not sSearchPageText: return
    sNextSearchPage = sNextPage.split('page/')[0].strip() + 'page/' + sSearchPageText + '/'
    showEntries(sNextSearchPage)
    cGui().setEndOfDirectory()
