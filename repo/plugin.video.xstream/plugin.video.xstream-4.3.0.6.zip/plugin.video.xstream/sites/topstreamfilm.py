# -*- coding: utf-8 -*-
# Python 3

# Always pay attention to the translations in the menu!
# HTML LangzeitCache hinzugefügt
# showValue:     48 Stunden
# showEntries:    6 Stunden
# showEpisodes:   4 Stunden

from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger, cParser
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui

SITE_IDENTIFIER = 'topstreamfilm'
SITE_NAME = 'Topstreamfilm'
SITE_ICON = 'topstreamfilm.png'
SITE_FANART = cConfig().getAddonInfo('path') + '/resources/art/sites/' + SITE_ICON

# Global search function is thus deactivated!
if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'false':
    SITE_GLOBAL_SEARCH = False
    logger.info('-> [SitePlugin]: globalSearch for %s is deactivated.' % SITE_NAME)

# Domain Abfrage
DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'www.topstreamfilm.live') # Domain Auswahl über die xStream Einstellungen möglich
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status') # Status Code Abfrage der Domain
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER) # Ob Plugin aktiviert ist oder nicht

URL_MAIN = 'https://' + DOMAIN
# URL_MAIN = 'https://www.topstreamfilm.live'

URL_ALL = URL_MAIN + '/filme-online-sehen/'
URL_MOVIES = URL_MAIN + '/beliebte-filme-online/'
URL_KINO = URL_MAIN + '/kinofilme/'
URL_SERIES = URL_MAIN + '/serien/'
URL_SEARCH = URL_MAIN + '/?story=%s&do=search&subaction=search'

SCRAPER_SETTINGS = f'''
            <group id="topstreamfilm" label="30707">
                <setting id="plugin_topstreamfilm" type="boolean" label="30050" help="30411">
                    <level>0</level>
                    <default>True</default>
                    <control type="toggle"/>
                </setting>
                <setting id="global_search_topstreamfilm" type="boolean" label="30052">
                    <level>0</level>
                    <default>True</default>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_topstreamfilm">false</dependency>
                    </dependencies>
                    <control type="toggle"/>
                </setting>
                <!-- Domain Überprüfung mit automatischer und manueller Anpassung -->
                <setting id="plugin_topstreamfilm_checkDomain" type="boolean" label="30277">
                    <visible>false</visible>
                    <default>True</default>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_topstreamfilm">false</dependency>
                        <dependency type="visible" operator="!is" setting="plugin_topstreamfilm">false</dependency>
                    </dependencies>
                    <control type="toggle"/>
                </setting>
                <setting id="plugin_topstreamfilm.domain" type="string" label="30278" help="">
                    <level>0</level>
                    <default>www.topstreamfilm.live</default>
                    <constraints>
                        <allowempty>true</allowempty>
                    </constraints>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_topstreamfilm">false</dependency>
                        <dependency type="visible" operator="!is" setting="plugin_topstreamfilm">false</dependency>
                    </dependencies>>
                    <control type="edit" format="string">
                        <heading>30278</heading>
                    </control>
                </setting>
                <setting id="plugin_topstreamfilm_status" type="string" label="Dummy" help="">
                    <visible>false</visible>
                    <default>true</default>
                    <control type="toggle"/>
                </setting>
            </group>
'''

def load(): # Menu structure of the site plugin
    logger.info('Load %s' % SITE_NAME)
    params = ParameterHandler()
    params.setParam('sUrl', URL_ALL)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30500), SITE_IDENTIFIER, 'showEntries'), params)  # New Movies and Series
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30502), SITE_IDENTIFIER, 'showMovieMenu'), params)  # Movies Menu
    params.setParam('sUrl', URL_SERIES)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30511), SITE_IDENTIFIER, 'showEntries'), params)  # Series
    cGui().addFolder(cGuiElement('Erscheinungsjahr', SITE_IDENTIFIER, 'showYears'), params)    # Jahre
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30506), SITE_IDENTIFIER, 'showGenre'), params)    # Genre
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30538), SITE_IDENTIFIER, 'showCountry'), params)  # Country
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showSearch'), params)   # Search
    cGui().setEndOfDirectory()


def showMovieMenu(): # Menu structure of movie menu
    params = ParameterHandler()
    params.setParam('sUrl', URL_MOVIES)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30500), SITE_IDENTIFIER, 'showEntries'), params)   # New
    params.setParam('sUrl', URL_KINO)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30501), SITE_IDENTIFIER, 'showEntries'), params)  # Kinofilme
    params.setParam('Value', 'FILM DER WOCHE')
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30550), SITE_IDENTIFIER, 'showEntries'), params) # Movie of the Week
    cGui().setEndOfDirectory()


def showGenre():
    params = ParameterHandler()
    genres = [
        ('Drama', URL_MAIN + '/drama/'), ('Serien', URL_MAIN + '/serien/'),
        ('Familie', URL_MAIN + '/familie/'), ('Fantasy', URL_MAIN + '/fantasy/'),
        ('Historie', URL_MAIN + '/historie/'), ('Horror', URL_MAIN + '/horror/'),
        ('Musik', URL_MAIN + '/musik/'), ('Mystery', URL_MAIN + '/mystery/'),
        ('Romantik', URL_MAIN + '/romantik/'), ('Reality-TV', URL_MAIN + '/reality-tv/'),
        ('Sci-Fi', URL_MAIN + '/sci-fi/'), ('Sport', URL_MAIN + '/sport/'),
        ('Thriller', URL_MAIN + '/thriller/'), ('Krieg', URL_MAIN + '/krieg/'),
        ('Western', URL_MAIN + '/western/'), ('Action', URL_MAIN + '/action/'),
        ('Abenteuer', URL_MAIN + '/abenteuer/'), ('Animation', URL_MAIN + '/animation/'),
        ('Biographie', URL_MAIN + '/biographie/'), ('Komödie', URL_MAIN + '/komodie/'),
        ('Krimi', URL_MAIN + '/krimi/'), ('Dokumentation', URL_MAIN + '/dokumentation/'),
        ('Demnächst', URL_MAIN + '/demnachst/'), ('Liebesfilm', URL_MAIN + '/liebesfilm/'),
        ('Kinofilme', URL_MAIN + '/kinofilme/'),
    ]
    for sName, sUrl in genres:
        params.setParam('sUrl', sUrl)
        cGui().addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showYears():
    params = ParameterHandler()
    import datetime
    current_year = datetime.datetime.now().year
    for year in range(current_year, 1989, -1):
        sUrl = URL_MAIN + '/xfsearch/%d' % year
        params.setParam('sUrl', sUrl)
        cGui().addFolder(cGuiElement(str(year), SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showCountry():
    params = ParameterHandler()
    countries = [
        ('USA', URL_MAIN + '/xfsearch/USA'), ('Canada', URL_MAIN + '/xfsearch/country/Canada/'),
        ('China', URL_MAIN + '/xfsearch/country/China/'), ('Japan', URL_MAIN + '/xfsearch/country/Japan/'),
        ('Taiwan', URL_MAIN + '/xfsearch/country/Taiwan/'), ('Thailand', URL_MAIN + '/xfsearch/country/Thailand/'),
        ('Belgium', URL_MAIN + '/xfsearch/country/Belgium/'), ('Israel', URL_MAIN + '/xfsearch/country/Israel/'),
    ]
    for sName, sUrl in countries:
        params.setParam('sUrl', sUrl)
        cGui().addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=False, sSearchPageText = False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    isTvshow = False
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6  # 6 Stunden
    sHtmlContent = oRequest.request()
    pattern = 'TPostMv">.*?href="([^"]+).*?data-src="([^"]+).*?Title">([^<]+)(.*?)</li>'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch:
        if not sGui: oGui.showInfo()
        return

    # Jahresfilter wenn URL /xfsearch/YYYY enthält
    import re as _re
    _ym = _re.search(r'/xfsearch/(\d{4})', entryUrl if entryUrl else '')
    if _ym:
        _yf = _ym.group(1)
        aResult = [r for r in aResult if _yf in r[3]][:16]
    elif sSearchText:
        aResult = [r for r in aResult if cParser.search(sSearchText, r[2].split('- Der Film')[0].strip())][:16]
    else:
        aResult = aResult[:16]
    total = len(aResult)
    for sUrl, sThumbnail, sName, sDummy in aResult:
        if sName:
            sName = sName.split('- Der Film')[0].strip() # Name nach dem - abschneiden und Array [0] nutzen
        isYear, sYear = cParser.parseSingleResult(sDummy, 'Year">([\d]+)</span>')  # Release Jahr
        isDuration, sDuration = cParser.parseSingleResult(sDummy, 'time">([\d]+)')  # Laufzeit
        # TV-Show Erkennung via Genre aus Detail-HTML (gecacht) - zuverlässiger als Laufzeit
        try:
            isTvshow = int(sDuration) <= 70 if isDuration else False
        except Exception:
            isTvshow = False
        isQuality, sQuality = cParser.parseSingleResult(sDummy, 'Qlty">([^<]+)</span>')  # Qualität
        isDesc, sDesc = cParser.parseSingleResult(sDummy, 'Description[^>]*><p>([^<]+)')  # Beschreibung
        if not isDesc:
            isDesc, sDesc = cParser.parseSingleResult(sDummy, 'Description.*?<p>([^<]+)')
        if sThumbnail and not sThumbnail.startswith('http'):
            sThumbnail = URL_MAIN + sThumbnail
        # Titelformat: Name - (Jahr) [Qualität]
        sDisplayTitle = sName.strip()
        if isYear and len(sYear) == 4:
            sDisplayTitle += ' - (%s)' % sYear
        if isQuality:
            sDisplayTitle += ' [%s]' % sQuality.strip()
        oGuiElement = cGuiElement(sDisplayTitle, SITE_IDENTIFIER, 'showSeasons' if isTvshow else 'showHosters')
        if isYear:
            oGuiElement.setYear(sYear)
        if isDuration:
            oGuiElement.addItemValue('duration', sDuration)
        if isQuality:
            oGuiElement.setQuality(sQuality)
        if isDesc:
            oGuiElement.setDescription(sDesc)
        oGuiElement.setMediaType('tvshow' if isTvshow else 'movie')
        oGuiElement.setThumbnail(sThumbnail)
        oGuiElement.setFanart(sThumbnail)

        # Detail-Request für Fanart (.webp→.jpg) UND Genre-Erkennung (gecacht)
        try:
            sDetailUrl = sUrl if sUrl.startswith('http') else URL_MAIN + sUrl
            sDetailHtml = cRequestHandler(sDetailUrl, caching=True, ignoreErrors=True).request()
            if sDetailHtml:
                # Fanart aus TPostBg
                isFanart, sFanart = cParser.parseSingleResult(sDetailHtml, r'TPostBg[^>]*data-src="([^"]+)"')
                if not isFanart:
                    isFanart, sFanart = cParser.parseSingleResult(sDetailHtml, r'property="og:image"[^>]*content="([^"]+)"')
                if isFanart:
                    if sFanart.startswith('/'):
                        sFanart = URL_MAIN + sFanart
                    if sFanart.startswith('http'):
                        sFanart = sFanart.replace('.webp', '.jpg')
                        oGuiElement.setFanart(sFanart)
                # Genre-basierte Serien-Erkennung
                isGenre, sGenre = cParser.parseSingleResult(sDetailHtml, r'Genre.*?</strong>(.*?)</li>')
                if isGenre and '/serien/' in sGenre.lower():
                    isTvshow = True
                    oGuiElement.setFunction('showSeasons')
                    oGuiElement.setMediaType('tvshow')
                elif isGenre:
                    isTvshow = False
                    oGuiElement.setFunction('showHosters')
                    oGuiElement.setMediaType('movie')
        except Exception:
            pass

        params.setParam('entryUrl', sUrl)
        params.setParam('sThumbnail', sThumbnail)
        params.setParam('sDesc', sDesc)
        oGui.addFolder(oGuiElement, params, isTvshow, total)
    if not sGui and not sSearchText and not sSearchPageText:
        isMatchNextPage, sNextUrl = cParser.parseSingleResult(sHtmlContent, 'href="([^"]+)">Next')

        # Start Page Function
        isMatchSiteSearch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, 'class="wp-pagenavi">(.*?)Next')
        if isMatchSiteSearch:
            isMatch, aResult = cParser.parse(sHtmlContainer, '<span>([\d]+)</span>.*?nav_ext">.*?">([\d]+)</a>.*?href="([^"]+)')
            for sPageActive, sPageLast, sNextPage in (aResult or []):
                #sPageName = '[I]Seitensuche starten  >>> [/I] Seite ' + str(sPageActive) + ' von ' + str(sPageLast) + ' Seiten  [I]<<<[/I]'
                sPageName = cConfig().getLocalizedString(30284) + str(sPageActive) + cConfig().getLocalizedString(30285) + str(sPageLast) + cConfig().getLocalizedString(30286)
                params.setParam('sNextPage', sNextPage)
                params.setParam('sPageLast', sPageLast)
                oGui.searchNextPage(sPageName, SITE_IDENTIFIER, 'showSearchPage', params)
        # End Page Function

        if isMatchNextPage:
            params.setParam('sUrl', sNextUrl)
            oGui.addNextPage(SITE_IDENTIFIER, 'showEntries', params)
        oGui.setView('tvshows' if isTvshow else 'movies')
        oGui.setEndOfDirectory()


def showSeasons():
    params = ParameterHandler()
    sUrl = params.getValue('entryUrl')
    sThumbnail = params.getValue('sThumbnail')
    sDesc = params.getValue('sDesc')
    oRequest = cRequestHandler(sUrl)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6
    sHtmlContent = oRequest.request()

    isImdb, sImdbId = cParser.parseSingleResult(sHtmlContent, r"var imdb\s*=\s*'(tt(\d+))'")
    isId, sShowId = cParser.parseSingleResult(sHtmlContent, r'var show_id\s*=\s*(\d+)')

    aSeasonNums = []
    sImdbNum = ''

    if isImdb and sImdbId:
        sImdbNum = sImdbId.replace('tt', '')
        sMcUrl = 'https://meinecloud.click/serial/%s?s=1&e=1' % sImdbNum
        sMcHtml = cRequestHandler(sMcUrl, caching=True).request() or ''
        isS, aLabels = cParser.parse(sMcHtml, r'_stab[^>]*>\s*S(\d+)\s*<')
        if isS and aLabels:
            aSeasonNums = aLabels
        else:
            isS2, aIds = cParser.parse(sMcHtml, r'data-season=["\']?(\d+)["\']?')
            aSeasonNums = [str(i+1) for i in range(len(aIds))] if (isS2 and aIds) else []

    if not aSeasonNums:
        if isId:
            sAjaxUrl = URL_MAIN + '/engine/ajax/controller.php?mod=getSerials&news_id=' + sShowId + '&action=getSeasons'
            sAjaxHtml = cRequestHandler(sAjaxUrl, caching=True).request() or ''
            isS3, aIds3 = cParser.parse(sAjaxHtml, r'data-season=["\']?(\d+)["\']?')
            aSeasonNums = [str(i+1) for i in range(len(aIds3))] if (isS3 and aIds3) else ['1']
        else:
            aSeasonNums = ['1']

    seen = set()
    aSeasonNums = [x for x in aSeasonNums if not (x in seen or seen.add(x))]
    params.setParam('sShowId', sShowId or '')
    params.setParam('sImdbNum', sImdbNum)
    total = len(aSeasonNums)
    for sSeason in aSeasonNums:
        oGuiElement = cGuiElement('Staffel ' + sSeason, SITE_IDENTIFIER, 'showEpisodes')
        oGuiElement.setSeason(sSeason)
        oGuiElement.setMediaType('season')
        oGuiElement.setThumbnail(sThumbnail)
        if sDesc:
            oGuiElement.setDescription(sDesc)
        cGui().addFolder(oGuiElement, params, True, total)
    cGui().setView('seasons')
    cGui().setEndOfDirectory()


def showEpisodes():
    params = ParameterHandler()
    entryUrl = params.getValue('entryUrl')
    sThumbnail = params.getValue('sThumbnail')
    sSeason = params.getValue('season')
    sShowId = params.getValue('sShowId')
    sDesc = params.getValue('sDesc')

    sImdbNum = params.getValue('sImdbNum')
    aEpNums = []
    aEpTitles = []

    if sImdbNum:
        sMcUrl = 'https://meinecloud.click/serial/%s?s=%s&e=1' % (sImdbNum, sSeason)
        sMcHtml = cRequestHandler(sMcUrl, caching=True).request() or ''
        isEpT, aEpTitles = cParser.parse(sMcHtml, r'_ep-t[^>]*>([^<]+)<')
        isLinks, aLinks = cParser.parse(sMcHtml, r'data-link=["\']([^"\'>]+)["\']')
        if isLinks and aLinks:
            aEpNums = [str(i+1) for i in range(len(aLinks))]

    if not aEpNums and sShowId:
        sAjaxUrl = URL_MAIN + '/engine/ajax/controller.php?mod=getSerials&news_id=' + sShowId + '&season=' + sSeason + '&action=getEpisodes'
        sAjaxHtml = cRequestHandler(sAjaxUrl, caching=True).request() or ''
        isM2, aR2 = cParser.parse(sAjaxHtml, r'data-episode=["\']?(\d+)["\']?')
        if isM2 and aR2:
            aEpNums = aR2

    if not aEpNums:
        aEpNums = ['1']

    seen = set()
    aEpNums = [x for x in aEpNums if not (x in seen or seen.add(x))]
    total = len(aEpNums)
    for i, sEpisode in enumerate(aEpNums):
        sEpTitle = 'Episode ' + sEpisode
        try:
            if aEpTitles and i < len(aEpTitles):
                sEpTitle = 'E%s — %s' % (sEpisode, aEpTitles[i].strip())
        except Exception:
            pass
        oGuiElement = cGuiElement(sEpTitle, SITE_IDENTIFIER, 'showEpisodeHosters')
        oGuiElement.setThumbnail(sThumbnail)
        if sDesc:
            oGuiElement.setDescription(sDesc)
        oGuiElement.setMediaType('episode')
        params.setParam('entryUrl', entryUrl)
        params.setParam('sShowId', sShowId)
        params.setParam('sImdbNum', sImdbNum)
        params.setParam('season', sSeason)
        params.setParam('episode', sEpisode)
        cGui().addFolder(oGuiElement, params, False, total)
    cGui().setView('episodes')
    cGui().setEndOfDirectory()


def showEpisodeHosters():
    hosters = []
    params = ParameterHandler()
    sUrl = params.getValue('entryUrl')
    sSeason = params.getValue('season')
    sEpisode = params.getValue('episode')
    sQuality = '720'

    # IMDB-ID aus gecachter Detailseite
    sHtmlContent = cRequestHandler(sUrl, caching=True).request() or ''
    isImdb, sImdbId = cParser.parseSingleResult(sHtmlContent, r"var imdb\s*=\s*'(tt(\d+))'")
    # sImdbNum bevorzugt aus params (von showSeasons/showEpisodes), sonst aus Detail-HTML
    sImdbNum_param = params.getValue('sImdbNum')

    if isImdb and sImdbId:
        sImdbNum = sImdbNum_param if sImdbNum_param else sImdbId.replace('tt', '')
        sMcPlayerUrl = 'https://meinecloud.click/serial/%s?s=%s&e=%s' % (sImdbNum, sSeason, sEpisode)
        sMcHtml = cRequestHandler(sMcPlayerUrl, caching=False).request() or ''

        if sMcHtml:
            isLinks, aLinks = cParser.parse(sMcHtml, r'data-link=["\']([^"\'>]+)["\']')
            if isLinks and aLinks:
                try:
                    idx = int(sEpisode) - 1
                    sDataLink = aLinks[idx] if idx < len(aLinks) else aLinks[0]
                except Exception:
                    sDataLink = aLinks[0]
                if sDataLink:
                    if sDataLink.startswith('//'):
                        sDataLink = 'https:' + sDataLink
                    sName = cParser.urlparse(sDataLink).split('.')[0].strip() or 'dr0pstream'
                    hosters.append({'link': sDataLink, 'name': sName,
                                    'displayedName': '%s [I][%sp][/I]' % (sName, sQuality),
                                    'quality': sQuality})

        if not hosters:
            sMcCheckUrl = 'https://meinecloud.click/serials.php?task=check&id_imdb=' + sImdbId
            sMcCheck = cRequestHandler(sMcCheckUrl, caching=False).request() or ''
            isUrl2, sPlayer2 = cParser.parseSingleResult(sMcCheck, r'"player_url"\s*:\s*"([^"]+)"')
            if isUrl2 and sPlayer2:
                sPlayer2 = sPlayer2.replace('\/', '/')
                sep = '&' if '?' in sPlayer2 else '?'
                sPlayer2 = sPlayer2 + sep + 's=%s&e=%s' % (sSeason, sEpisode)
                hosters.append({'link': sPlayer2, 'name': 'meinecloud',
                                'displayedName': 'meinecloud [I][%sp][/I]' % sQuality,
                                'quality': sQuality})

    if hosters:
        hosters.append('getHosterUrl')
    return hosters


def showHosters():
    hosters = []
    params = ParameterHandler()
    sUrl = params.getValue('entryUrl')
    sHtmlContent = cRequestHandler(sUrl, caching=False).request()
    pattern = '<iframe.*?src="([^"]+)'
    isMatch, hUrl = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatch:
        sHtmlContainer = cRequestHandler(hUrl).request()
        isMatch, aResult = cParser.parse(sHtmlContainer, 'data-link="([^"]+)')
        if isMatch:
            sQuality = '720'
            for sUrl in aResult:
                if 'youtube' in sUrl:
                    continue
                elif sUrl.startswith('//'):
                    sUrl = 'https:' + sUrl
                sName = cParser.urlparse(sUrl).split('.')[0].strip()
                if cConfig().isBlockedHoster(sName)[0]: continue  # Hoster aus settings.xml oder deaktivierten Resolver ausschließen
                hoster = {'link': sUrl, 'name': sName, 'displayedName': '%s [I][%sp][/I]' % (sName, sQuality), 'quality': sQuality}
                hosters.append(hoster)
        if hosters:
            hosters.append('getHosterUrl')
        return hosters


def getHosterUrl(sUrl=False):
    if sUrl and 'meinecloud.click/serial' in sUrl:
        try:
            sHtml = cRequestHandler(sUrl, caching=False).request() or ''
            for pat in [
                r'["\'](https?://[^"\']+\.m3u8[^"\']*)["\'\s]',
                r'["\'](https?://[^"\']+\.mp4[^"\']*)["\'\s]',
                r'file\s*:\s*["\'](https?://[^"\'>]+)["\'\s]',
            ]:
                isM, aR = cParser.parse(sHtml, pat)
                if isM and aR:
                    return [{'streamUrl': aR[0], 'resolved': True}]
        except Exception:
            pass
    return [{'streamUrl': sUrl, 'resolved': False}]


def showSearch():
    sSearchText = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
    if not sSearchText: return
    _search(False, sSearchText)
    cGui().setEndOfDirectory()


def _search(oGui, sSearchText):
    showEntries(URL_SEARCH % cParser.quotePlus(sSearchText), oGui, sSearchText)


def showSearchPage(): # Suche für die Page Funktion
    params = ParameterHandler()
    sNextPage = params.getValue('sNextPage') # URL mit nächster Seite
    sPageLast = params.getValue('sPageLast') # Anzahl gefundener Seiten
    #sHeading = 'Bitte eine Zahl zwischen 1 und ' + str(sPageLast) + ' wählen.'
    sHeading = cConfig().getLocalizedString(30282) + str(sPageLast)
    sSearchPageText = cGui().showKeyBoard(sHeading=sHeading)
    if not sSearchPageText: return
    sNextSearchPage = sNextPage.split('page/')[0].strip() + 'page/' + sSearchPageText + '/'
    showEntries(sNextSearchPage)
    cGui().setEndOfDirectory()