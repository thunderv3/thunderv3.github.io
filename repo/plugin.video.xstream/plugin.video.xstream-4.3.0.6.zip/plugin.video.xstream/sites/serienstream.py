# -*- coding: utf-8 -*-
# Python 3

# Always pay attention to the translations in the menu!
# Sprachauswahl für Hoster enthalten.
# Ajax Suchfunktion enthalten.
# HTML LangzeitCache hinzugefügt
# showValue:     24 Stunden
# showAllSeries: 24 Stunden
# showEpisodes:   4 Stunden
# SSsearch:      24 Stunden
    
# 2022-12-06 Heptamer - Suchfunktion überarbeitet
# 2026-12-29 viewIT   - Hotfix wegen V2 von Serienstream 
# 2026-02-02 viewIT   - Anpassungen wegen neuem Layout / Katalog

import xbmcgui
import json
import re
from urllib.parse import quote_plus

from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger, cParser, cUtil
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui

SITE_IDENTIFIER = 'serienstream'
SITE_NAME = 'SerienStream'
SITE_ICON = 'serienstream.png'

# Global search function is thus deactivated!
if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'false':
    SITE_GLOBAL_SEARCH = False
    logger.info('-> [SitePlugin]: globalSearch for %s is deactivated.' % SITE_NAME)

# Domain Abfrage
DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain') # Domain Auswahl über die xStream Einstellungen möglich
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status') # Status Code Abfrage der Domain
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER) # Ob Plugin aktiviert ist oder nicht

# URL_MAIN = 'https://s.to/'
if DOMAIN == '186.2.175.5': # Bei Proxy Änderung nur IP hier in den Settings und in Zeile 53 tauschen.
    URL_MAIN = 'http://' + DOMAIN
    REFERER = 'http://' + DOMAIN
    proxy = 'true'
else:
    URL_MAIN = 'https://' + DOMAIN
    REFERER = 'https://' + DOMAIN
    proxy = 'false'
URL_SERIES = URL_MAIN + '/serien'
URL_NEW_SERIES = URL_MAIN + '/serien?by=alpha'
URL_NEW_EPISODES = URL_MAIN
URL_POPULAR = URL_MAIN + '/beliebte-serien'
URL_LOGIN = URL_MAIN + '/login'
URL_SEARCH = URL_MAIN + '/suche?term='
URL_SEARCH_API = URL_MAIN + '/api/search/suggest?term='

# Wenn DNS Bypass aktiv nutze Proxy Server
if cConfig().getSetting('bypassDNSlock') == 'true':
    cConfig().setSetting('plugin_' + SITE_IDENTIFIER + '.domain', '186.2.175.5')

#

def _abs_url(url):
    if not url:
        return ''
    if url.startswith('http://') or url.startswith('https://'):
        return url
    return URL_MAIN + url if url.startswith('/') else URL_MAIN + '/' + url


def _normalize_series_root(url):
    if not url:
        return ''
    full = _abs_url(url).split('?', 1)[0].split('#', 1)[0].replace('\\/', '/').rstrip('/')
    full = re.sub(r'/staffel-\d+(?:/.*)?$', '', full)
    full = re.sub(r'/episode-\d+(?:/.*)?$', '', full)
    return full


def _norm_search_text(value):
    value = (value or '').lower()
    value = re.sub(r'[^a-z0-9]+', ' ', value)
    value = re.sub(r'\s+', ' ', value).strip()
    return value


def _search_title_match(query, title):
    q = _norm_search_text(query)
    if not q:
        return False
    t = ' ' + _norm_search_text(title) + ' '
    return (' ' + q + ' ') in t

def load(): # Menu structure of the site plugin
    logger.info('Load %s' % SITE_NAME)
    params = ParameterHandler()
    username = cConfig().getSetting('serienstream.user')# Username
    password = cConfig().getSetting('serienstream.pass')# Password
    if username == '' or password == '':                # If no username and password were set, close the plugin!
        xbmcgui.Dialog().ok(cConfig().getLocalizedString(30241), cConfig().getLocalizedString(30264))   # Info Dialog!
    else:
        params.setParam('sUrl', URL_SERIES)
        cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30518), SITE_IDENTIFIER, 'showAllSeries'), params)# All Series
        params.setParam('sUrl', URL_NEW_SERIES)
        cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30514), SITE_IDENTIFIER, 'showEntries'), params)  # New Series
        params.setParam('sUrl', URL_NEW_EPISODES)
        cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30516), SITE_IDENTIFIER, 'showNewEpisodes'), params)  # New Episodes
        params.setParam('sUrl', URL_POPULAR)
        cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30519), SITE_IDENTIFIER, 'showEntries'), params)  # Popular Series
        params.setParam('sUrl', URL_MAIN + '/serien?by=alpha')
        params.setParam('sCont', 'catalogNav')
        # HOTFIX: A-Z über neues Alphabet-Layout (/katalog/*)
        cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30517), SITE_IDENTIFIER, 'showValue'), params)
        params.setParam('sUrl', URL_MAIN + '/serien?by=genre')
        params.setParam('sCont', 'homeContentGenresList')
        cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30506), SITE_IDENTIFIER, 'showValue'), params)  # Genre
        cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showSearch'), params)   # Search
        cGui().setEndOfDirectory()


def showValue():
    params = ParameterHandler()
    sUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(sUrl)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 24 # HTML Cache Zeit 1 Tag
    sHtmlContent = oRequest.request()
    isMatch = False
    aResult = []

    # Neues Layout (2026): Alphabet-Bar mit Links /katalog/A ... /katalog/0-9
    if params.getValue('sCont') == 'catalogNav':
        isMatch, aResult = cParser.parse(
            sHtmlContent,
            '<a[^>]*href="([^"]*/katalog/[^"]+)"[^>]*class="[^"]*alphabet-link[^"]*"[^>]*>\\s*([^<]+)\\s*<'
        )
        if not isMatch:
            isMatch, aResult = cParser.parse(
                sHtmlContent,
                '<a[^>]*href="(/katalog/[^"]+)"[^>]*class="[^"]*alphabet-link[^"]*"[^>]*>\\s*([^<]+)\\s*<'
            )

    # Neues Layout (2026): Genres auf /serien?by=genre als background-1 h3
    if not isMatch and params.getValue('sCont') == 'homeContentGenresList':
        isMatch, aResult = cParser.parse(
            sHtmlContent,
            '<div[^>]*class="[^"]*background-1[^"]*"[^>]*>\\s*<h3[^>]*>\\s*([^<]+)\\s*</h3>'
        )
        if isMatch and aResult:
            # cParser.parse liefert hier 1-tuple pro Treffer -> in (url,name)-Format umwandeln
            aResult = [(params.getValue('sUrl'), g[0] if isinstance(g, (list, tuple)) else g) for g in aResult]

    if not isMatch:
        cGui().showInfo()
        return

    for sUrl, sName in aResult:
        sUrl = sUrl if sUrl.startswith('http') else URL_MAIN + sUrl
        params.setParam('sUrl', sUrl)
        if params.getValue('sCont') == 'homeContentGenresList':
            params.setParam('sGenre', cUtil.cleanse_text(sName).strip())
        cGui().addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showAllSeries(entryUrl=False, sGui=False, sSearchText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 24 # HTML Cache Zeit 1 Tag
    sHtmlContent = oRequest.request()
    pattern = '<a[^>]*href="(\\/serie\\/[^"]*)"[^>]*>(.*?)</a>'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch:
        if not sGui: oGui.showInfo()
        return

    total = len(aResult)
    for sUrl, sName in aResult:
        if sSearchText and not cParser.search(sSearchText, sName):
            continue
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showSeasons')
        oGuiElement.setMediaType('tvshow')
        params.setParam('sUrl', sUrl if sUrl.startswith('http') else URL_MAIN + sUrl)
        params.setParam('TVShowTitle', sName)
        oGui.addFolder(oGuiElement, params, True, total)
    if not sGui:
        oGui.setView('tvshows')
        oGui.setEndOfDirectory()


def showNewEpisodes(entryUrl=False, sGui=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not entryUrl:
        entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 4 # HTML Cache Zeit 4 Stunden
    sHtmlContent = oRequest.request()
    # Neues Layout (2026): Startseite -> latest-episode-row
    pattern = '<a[^>]*class="[^"]*latest-episode-row[^"]*"[^>]*href="([^"]*/serie/[^"]*/staffel-(\\d+)/episode-(\\d+))"[^>]*>[\\s\\S]*?<span[^>]*class="ep-title"[^>]*>([^<]+)</span>'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)

    if not isMatch or not aResult:
        if not sGui: oGui.showInfo()
        return

    total = len(aResult)
    for sUrl, sSeason, sEpisode, sName in aResult:
        fullUrl = _abs_url(sUrl)
        seriesUrl = re.sub(r'/staffel-\\d+/episode-\\d+$', '', fullUrl)
        displayTitle = sName.strip()
        try:
            seasonNo = int(sSeason)
            episodeNo = int(sEpisode)
        except Exception:
            seasonNo = 0
            episodeNo = 0
        if seasonNo > 0 and episodeNo > 0:
            displayTitle = '%s - S%02dE%02d' % (displayTitle, seasonNo, episodeNo)

        oGuiElement = cGuiElement(displayTitle, SITE_IDENTIFIER, 'showHosters')
        oGuiElement.setMediaType('episode')
        oGuiElement.setTVShowTitle(sName.strip())
        if seasonNo > 0:
            oGuiElement.setSeason(seasonNo)
        if episodeNo > 0:
            oGuiElement.setEpisode(episodeNo)
        params.setParam('sUrl', fullUrl)
        params.setParam('entryUrl', seriesUrl)
        params.setParam('TVShowTitle', sName.strip())
        oGui.addFolder(oGuiElement, params, False, total)

    if not sGui:
        oGui.setView('episodes')
        oGui.setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not entryUrl:
        entryUrl = params.getValue('sUrl')
    sGenre = params.getValue('sGenre')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6 # HTML Cache Zeit 6 Stunden
    sHtmlContent = oRequest.request()
    # Neues/Altes Layout robust + schnell parsen.
    aResult = []
    isMatch = False

    # Genre-Ansicht (by=genre): nur gewählte Genre-Gruppe extrahieren.
    if sGenre:
        escaped = re.escape(sGenre)
        isBlock, sContainer = cParser.parseSingleResult(
            sHtmlContent,
            '<div[^>]*class="[^"]*background-1[^"]*"[^>]*>\\s*<h3[^>]*>\\s*%s\\s*</h3>[\\s\\S]*?</div>\\s*<ul[^>]*class="[^"]*series-list[^"]*"[^>]*>([\\s\\S]*?)</ul>' % escaped
        )
        if isBlock and sContainer:
            isMatch, aResult = cParser.parse(
                sContainer,
                '<a[^>]*href="([^"]*/serie/[^"]+)"[^>]*>\\s*([^<]+)\\s*</a>'
            )

    # 1) Sehr schnelles Listen-Layout (/serien?by=alpha oder /serien?by=genre).
    if not isMatch:
        isMatch, aResult = cParser.parse(
            sHtmlContent,
            '<li[^>]*class="[^"]*series-item[^"]*"[^>]*>\\s*<a[^>]*href="([^"]*/serie/[^"]+)"[^>]*>([^<]+)<\\/a>'
        )

    # 2) Card-Layout (/katalog/*, /beliebte-serien) mit Poster-ALT als Titel.
    if not isMatch:
        isMatch, aResult = cParser.parse(
            sHtmlContent,
            '<a[^>]*href="([^"]*/serie/[^"]+)"[^>]*class="[^"]*show-card[^"]*"[^>]*>[\\s\\S]*?<img[^>]+alt="([^"]+)"'
        )
    if not isMatch:
        isMatch, aResult = cParser.parse(
            sHtmlContent,
            '<a[^>]*href="([^"]*/serie/[^"]+)"[^>]*class="[^"]*show-cover[^"]*"[^>]*>[\\s\\S]*?<img[^>]+alt="([^"]+)"'
        )

    if not isMatch or not aResult:
        if not sGui: oGui.showInfo()
        return

    # Thumbnail-Map nur für Card-Layouts (katalog/popular).
    # Bei /serien?by=alpha ist das Parsing sonst unnötig teuer.
    thumbMap = {}
    if ('show-card' in sHtmlContent or 'show-cover' in sHtmlContent) and '/serien?by=alpha' not in entryUrl:
        isThumb, thumbResult = cParser.parse(
            sHtmlContent,
            '<a[^>]*href="([^"]*/serie/[^"]+)"[^>]*>[\\s\\S]*?<img[^>]*(?:data-src|src)="([^"]+)"[^>]*>'
        )
        if isThumb:
            for tUrl, tImg in thumbResult:
                key = _normalize_series_root(tUrl)
                if key and key not in thumbMap:
                    thumbMap[key] = _abs_url(tImg)

    # Dedupe + URL/Titel normalisieren
    cleaned = []
    seen = set()
    for sUrl, sName in aResult:
        sUrl = sUrl.strip()
        sName = cUtil.cleanse_text(sName).strip()
        if not sUrl or not sName:
            continue
        fullUrl = _normalize_series_root(sUrl)
        if '/serie/' not in fullUrl:
            continue
        key = (fullUrl.lower(), sName.lower())
        if key in seen:
            continue
        seen.add(key)
        cleaned.append((fullUrl, sName, thumbMap.get(fullUrl, '')))
        # Große Listen im Kodi-UI begrenzen, damit es nicht "ewig" lädt.
        if len(cleaned) >= 500:
            break

    if not cleaned:
        if not sGui: oGui.showInfo()
        return

    total = len(cleaned)
    for sUrl, sName, sThumbnail in cleaned:
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showSeasons')
        oGuiElement.setMediaType('tvshow')
        if sThumbnail:
            oGuiElement.setThumbnail(sThumbnail)
        params.setParam('sUrl', sUrl)
        params.setParam('TVShowTitle', sName)
        oGui.addFolder(oGuiElement, params, True, total)
    if not sGui:
        oGui.setView('tvshows')
        oGui.setEndOfDirectory()


def showSeasons():
    params = ParameterHandler()
    sUrl = params.getValue('sUrl')
    sTVShowTitle = params.getValue('TVShowTitle')
    oRequest = cRequestHandler(sUrl)
    sHtmlContent = oRequest.request()
    pattern = '<a[^>]*href="([^"]*/staffel-\\d+)"[^>]*data-season-pill="(\\d+)"[^>]*>\\s*(\\d+)\\s*<'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch:
        cGui().showInfo()
        return

    isDesc, sDesc = cParser.parseSingleResult(sHtmlContent, '<div[^>]*class="series-description"[^>]*>.*?<span[^>]*class="description-text">([^<]+)</span>')
    isThumbnail = False
    sThumbnail = ''
    thumbPatterns = [
        # 2026 detail layout (mobile/desktop cover blocks)
        'show-cover-mobile[\\s\\S]*?<img[^>]*(?:data-src|src)="([^"]+)"',
        'show-cover[^>]*>[\\s\\S]*?<img[^>]*(?:data-src|src)="([^"]+)"',
        # fallback: first channel-cover image
        '<img[^>]*(?:data-src|src)="([^"]*\\/media\\/images\\/channel\\/[^"]+)"',
        # generic fallback
        '<img[^>]*(?:data-src|src)="([^"]+)"[^>]*alt="[^"]+"'
    ]
    for p in thumbPatterns:
        isThumbnail, sThumbnail = cParser.parseSingleResult(sHtmlContent, p)
        if isThumbnail and sThumbnail:
            sThumbnail = _abs_url(sThumbnail)
            break

    total = len(aResult)
    for sUrl, sNr, _ in aResult:
        isMovie = sUrl.endswith('filme')
        sName = 'Staffel %s' % sNr
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showEpisodes')
        oGuiElement.setMediaType('season' if not isMovie else 'movie')
        if isThumbnail:
            oGuiElement.setThumbnail(sThumbnail)
        if isDesc:
            oGuiElement.setDescription(sDesc)
        if not isMovie:
            oGuiElement.setTVShowTitle(sTVShowTitle)
            oGuiElement.setSeason(sNr)
            params.setParam('sSeason', sNr)
        params.setParam('sThumbnail', sThumbnail)
        params.setParam('sUrl', sUrl if sUrl.startswith('http') else URL_MAIN + sUrl)
        cGui().addFolder(oGuiElement, params, True, total)
    cGui().setView('seasons')
    cGui().setEndOfDirectory()


def showEpisodes():
    params = ParameterHandler()
    sUrl = params.getValue('sUrl')
    sTVShowTitle = params.getValue('TVShowTitle')
    sSeason = params.getValue('sSeason')
    sThumbnail = params.getValue('sThumbnail')
    if not sSeason:
        sSeason = '0'
    isMovieList = sUrl.endswith('filme')
    oRequest = cRequestHandler(sUrl)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 4  # HTML Cache Zeit 4 Stunden
    sHtmlContent = oRequest.request()
    pattern = 'onclick="window.location=\\\'([^\\\']+)\\\'".*?episode-number-cell">\\s*(\\d+).*?episode-title-ger"[^>]*>([^<]*)<.*?episode-title-eng"[^>]*>([^<]*)<'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch:
        cGui().showInfo()
        return

    isDesc, sDesc = cParser.parseSingleResult(sHtmlContent, '<div[^>]*class="series-description"[^>]*>.*?<span[^>]*class="description-text">([^<]+)</span>')
    total = len(aResult)
    for sUrl2, sID, sNameGer, sNameEng in aResult:
        sName = '%d - ' % int(sID)
        sName += sNameGer if sNameGer else sNameEng
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showHosters')
        oGuiElement.setMediaType('episode' if not isMovieList else 'movie')
        oGuiElement.setThumbnail(sThumbnail)
        if isDesc:
            oGuiElement.setDescription(sDesc)
        if not isMovieList:
            oGuiElement.setSeason(sSeason)
            oGuiElement.setEpisode(int(sID))
            oGuiElement.setTVShowTitle(sTVShowTitle)
        params.setParam('sUrl', sUrl2 if sUrl2.startswith('http') else URL_MAIN + sUrl2)
        params.setParam('entryUrl', sUrl)
        cGui().addFolder(oGuiElement, params, False, total)
    cGui().setView('episodes' if not isMovieList else 'movies')
    cGui().setEndOfDirectory()


def showHosters():
    hosters = []
    sUrl = ParameterHandler().getValue('sUrl')
    sHtmlContent = cRequestHandler(sUrl, caching=False).request()
    pattern = '<button[^>]*class="[^"]*link-box[^"]*"[^>]*data-play-url="([^"]+)"[^>]*data-provider-name="([^"]+)"[^>]*data-language-id="([^"]+)"'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if isMatch:
        for sUrl, sName, sLang in aResult:
            if cConfig().isBlockedHoster(sName)[0]: continue
            sLanguage = cConfig().getSetting('prefLanguage')
            if sLanguage == '1' and sLang != '1': continue
            if sLanguage == '2' and sLang != '2': continue
            if sLanguage == '3':  # Japanisch/andere nicht verfügbar
                cGui().showLanguage()
                continue
            if sLanguage == '0':
                sLang = '(DE)' if sLang == '1' else '(EN)' if sLang == '2' else sLang
            else:
                sLang = '(DE)' if sLang == '1' else '(EN)' if sLang == '2' else sLang
            sQuality = '480'
            hoster = {'link': [sUrl, sName], 'name': sName, 'displayedName': '%s [I]%s [%sp][/I]' % (sName, sLang, sQuality), 'quality': sQuality, 'languageCode': sLang}
            hosters.append(hoster)
        if hosters:
            hosters.append('getHosterUrl')
        if not hosters:
            cGui().showLanguage()
        return hosters


def getHosterUrl(hUrl):
    if type(hUrl) == str: hUrl = eval(hUrl)
    Request = cRequestHandler(URL_MAIN + hUrl[0], caching=False)
    Request.addHeaderEntry('Referer', ParameterHandler().getValue('entryUrl'))
    Request.addHeaderEntry('Upgrade-Insecure-Requests', '1')
    Request.request()
    sUrl = Request.getRealUrl()

    if 'voe' in hUrl[1].lower():
        isBlocked, sDomain = cConfig().isBlockedHoster(sUrl)  # Die funktion gibt 2 werte zurück!
        if isBlocked:  # Voe Pseudo sDomain nicht bekannt in resolveUrl
            sUrl = sUrl.replace(sDomain, 'voe.sx')
            return [{'streamUrl': sUrl, 'resolved': False}]

    return [{'streamUrl': sUrl, 'resolved': False}]


def showSearch():
    sSearchText = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
    if not sSearchText: return
    _search(False, sSearchText)
    cGui().setEndOfDirectory()


def _search(oGui, sSearchText):
    SSsearch(oGui, sSearchText)


def SSsearch(sGui=False, sSearchText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    params.getValue('sSearchText')
    sst = sSearchText.lower().strip()
    aResult = []

    # 2026-Layout: Schnellsuche läuft über API-Endpunkt.
    try:
        oRequest = cRequestHandler(URL_SEARCH_API + quote_plus(sSearchText), caching=False, ignoreErrors=(sGui is not False))
        sApiContent = oRequest.request()
        if sApiContent:
            data = json.loads(sApiContent)
            for item in data.get('shows', []):
                title = (item.get('name') or '').strip()
                link = (item.get('url') or '').strip()
                if not title or not link:
                    continue
                aResult.append((link if link.startswith('http') else URL_MAIN + link, title))
    except Exception:
        pass

    if not aResult:
        oGui.showInfo()
        return

    total = len(aResult)
    for link, title in aResult:
        titleLow = title.lower()
        if not _search_title_match(sSearchText, title) and not cUtil.isSimilarByToken(_norm_search_text(sSearchText), _norm_search_text(title)):
            continue
        else:
            #get images thumb / descr pro call. (optional)
            try:
                sThumbnail, sDescription = getMetaInfo(link, title)
                oGuiElement = cGuiElement(title, SITE_IDENTIFIER, 'showSeasons')
                if sThumbnail:
                    oGuiElement.setThumbnail(_abs_url(sThumbnail))
                oGuiElement.setDescription(sDescription)
                oGuiElement.setTVShowTitle(title)
                oGuiElement.setMediaType('tvshow')
                params.setParam('sUrl', link if link.startswith('http') else URL_MAIN + link)
                params.setParam('sName', title)
                oGui.addFolder(oGuiElement, params, True, total)
            except Exception:
                oGuiElement = cGuiElement(title, SITE_IDENTIFIER, 'showSeasons')
                oGuiElement.setTVShowTitle(title)
                oGuiElement.setMediaType('tvshow')
                params.setParam('sUrl', link if link.startswith('http') else URL_MAIN + link)
                params.setParam('sName', title)
                oGui.addFolder(oGuiElement, params, True, total)

        if not sGui:
            oGui.setView('tvshows')


def getMetaInfo(link, title):   # Setzen von Metadata in Suche:
    oGui = cGui()
    oRequest = cRequestHandler(link if link.startswith('http') else URL_MAIN + link, caching=False)
    sHtmlContent = oRequest.request()
    if not sHtmlContent:
        return

    patterns = [
        'show-cover-mobile[\\s\\S]*?(?:data-src|src)="([^"]+)"[\\s\\S]*?class="series-description"[\\s\\S]*?<span[^>]*class="description-text">([^<]+)</span>',
        '<img[^>]*(?:data-src|src)="([^"]*\\/media\\/images\\/channel\\/[^"]+)"[\\s\\S]*?class="series-description"[\\s\\S]*?<span[^>]*class="description-text">([^<]+)</span>',
        '<img[^>]*(?:data-src|src)="([^"]+)"[\\s\\S]*?class="series-description"[\\s\\S]*?<span[^>]*class="description-text">([^<]+)</span>'
    ]
    for pattern in patterns:
        isMatch, aResult = cParser.parse(sHtmlContent, pattern)
        if not isMatch:
            continue
        for sImg, sDescr in aResult:
            return _abs_url(sImg), sDescr
