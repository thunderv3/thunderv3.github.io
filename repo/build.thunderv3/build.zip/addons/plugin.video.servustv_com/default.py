﻿# -*- coding: utf-8 -*-

'''
    Copyright (C) 2023 realvito

    ServusTV.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
'''

from resources.lib.common import *
from resources.lib import navigator


def run():
	if mode == 'root': ##### Delete old Files in Userdata-Folder 'settings' to cleanup old Entries #####
		DONE = False    ##### [plugin.video.servustv_com v.3.0.1+v.3.0.8+v.3.0.9] - 13.04.2021+16.06.2024+18.06.2024 #####
		firstSCRIPT = xbmcvfs.translatePath(os.path.join(f"special://home{os.sep}addons{os.sep}{addon_id}{os.sep}lib{os.sep}")).encode('utf-8').decode('utf-8')
		UNO = xbmcvfs.translatePath(os.path.join(firstSCRIPT, 'only_at_FIRSTSTART'))
		if xbmcvfs.exists(UNO):
			SERCOM = xbmcvfs.translatePath(os.path.join(f"special://home{os.sep}userdata{os.sep}addon_data{os.sep}{addon_id}{os.sep}")).encode('utf-8').decode('utf-8')
			OLD_SETTINGS = xbmcvfs.translatePath(os.path.join(SERCOM, 'settings.xml'))
			try:
				xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0", "id":1, "method":"Addons.SetAddonEnabled", "params":{{"addonid":"{addon_id}", "enabled":false}}}}')
				if xbmcvfs.exists(OLD_SETTINGS):
					xbmcvfs.delete(OLD_SETTINGS) # Delete OLD_SETTINGS File
			except: pass
			xbmcvfs.delete(UNO)
			xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0", "id":1, "method":"Addons.SetAddonEnabled", "params":{{"addonid":"{addon_id}", "enabled":true}}}}')
			xbmc.sleep(500)
			DONE = True
		else:
			DONE = True
		if DONE is True: navigator.mainMenu()
	elif mode == 'unsubscribe':
		navigator.unsubscribe()
	elif mode == 'listGenerals':
		navigator.listGenerals(url, phrase, searching, page, limit)
	elif mode == 'listThemes':
		navigator.listThemes(url, phrase, page, limit)
	elif mode == 'SearchSERVUSTV':
		navigator.SearchSERVUSTV()
	elif mode == 'listChannels':
		navigator.listChannels()
	elif mode == 'playVideo':
		navigator.playVideo(url, action)
	elif mode == 'listFavorites':
		navigator.listFavorites()
	elif mode == 'favs':
		navigator.favs(action, name, pict, url, plot, wallpaper, cineType)
	elif mode == 'blankFUNC':
		pass # do nothing
	elif mode == 'newsFUNC':
		navigator.message(action)
	elif mode == 'aConfigs':
		addon.openSettings()
		xbmc.executebuiltin('Container.Refresh')
	elif mode == 'iConfigs':
		xbmcaddon.Addon('inputstream.adaptive').openSettings()

run()
