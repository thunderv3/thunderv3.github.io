﻿# -*- coding: utf-8 -*-

import sys
import os
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import json
import xbmcvfs
import shutil
import socket
import time
import base64
from datetime import datetime, timedelta
import requests
import ssl
from urllib.parse import parse_qsl, urlparse, urlencode, quote_plus, unquote_plus
from urllib.request import urlopen
from functools import reduce
from concurrent.futures import *
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


socket.setdefaulttimeout(30)
HOST_AND_PATH				= sys.argv[0]
ADDON_HANDLE				= int(sys.argv[1])
dialog									= xbmcgui.Dialog()
addon									= xbmcaddon.Addon()
addon_id							= addon.getAddonInfo('id')
addon_name						= addon.getAddonInfo('name')
addon_version					= addon.getAddonInfo('version')
addonPath							= xbmcvfs.translatePath(addon.getAddonInfo('path'))
dataPath							= xbmcvfs.translatePath(addon.getAddonInfo('profile'))
WORKS_FILE						= xbmcvfs.translatePath(os.path.join(dataPath, 'episode_data.json'))
defaultFanart					= os.path.join(addonPath, 'resources', 'media', 'fanart.jpg')
icon										= os.path.join(addonPath, 'resources', 'media', 'icon.png')
artpic									= os.path.join(addonPath, 'resources', 'media', '')
enableINPUTSTREAM		= addon.getSetting('useInputstream') == 'true'
prefSTREAM						= int(addon.getSetting('prefer_stream'))
showDATE							= addon.getSetting('show_dates') == 'true'
showCHANNEL					= addon.getSetting('show_channel') == 'true'
showARTE							= (True if addon.getSetting('show_ARTE') == 'true' else False)
showJOYN							= (True if addon.getSetting('show_JOYN') == 'true' else False)
showSERVUS						= (True if addon.getSetting('show_SERVUS') == 'true' else False)
showTELE							= (True if addon.getSetting('show_TELE5') == 'true' else False)
showRTL								= (True if addon.getSetting('show_TVNOW') == 'true' else False)
useThumbAsFanart			= addon.getSetting('use_fanart') == 'true'
enableADJUSTMENT		= addon.getSetting('show_settings') == 'true'
DEB_LEVEL							= (xbmc.LOGINFO if addon.getSetting('enable_debug') == 'true' else xbmc.LOGDEBUG)
JOYN_staticCODE				= addon.getSetting('joyn_staticCODE')
ARTEEX								= ['ARTE']
JOYNEX								= ['DMAX', 'KABEL 1', 'PROSIEBEN', 'PROSIEBEN MAXX', 'SAT.1', 'SAT.1 GOLD', 'SIXX']
SERVUSEX							= ['SERVUSTV DEUTSCHLAND']
TELEEX								= ['TELE 5']
RTLEX									= ['NITRO', 'RTL', 'RTL 2', 'RTLUP', 'VOX', 'SRTL', 'TOGGO PLUS']
KODI_ov20							= int(xbmc.getInfoLabel('System.BuildVersion')[0:2]) >= 20
KODI_un21							= int(xbmc.getInfoLabel('System.BuildVersion')[0:2]) <= 20
BASE_URL							= 'https://www.tvspielfilm.de'
BASE_JOYN						= 'https://www.joyn.de/'
API_ARD								= 'https://api.ardmediathek.de/page-gateway/pages/'
API_ZDF								= 'https://api.zdf.de'
API_JOYN							= 'https://www.joyn.de/_next/data/' # bSD_wV8RvFrdlX8nHD5vh # CODE of the Webpage

xbmcplugin.setContent(ADDON_HANDLE, 'tvshows')

def py3_dec(d, nom='utf-8', ign='ignore'):
	if isinstance(d, bytes):
		d = d.decode(nom, ign)
	return d

def translation(id):
	return addon.getLocalizedString(id)

def failing(content):
	log(content, xbmc.LOGERROR)

def debug_MS(content):
	log(content, DEB_LEVEL)

def log(msg, level=xbmc.LOGINFO):
	return xbmc.log(f"[{addon_id} v.{addon_version}]{str(msg)}", level)

def build_mass(plugin, body):
	return f"{plugin}?{urlencode(body)}"

def get_userAgent(REV='130.0', VER='130.0'):
	base = f"Mozilla/5.0 {{}} Gecko/20100101 Firefox/{VER}"
	if xbmc.getCondVisibility('System.Platform.Android'):
		if 'arm' in os.uname()[4]: return base.format(f"(X11; Linux arm64; rv:{REV})") # ARM based Linux
		return base.format(f"(X11; Linux x86_64; rv:{REV})") # x64 Linux
	elif xbmc.getCondVisibility('System.Platform.Windows'):
		return base.format(f"(Windows NT 10.0; Win64; x64; rv:{REV})") # Windows
	elif xbmc.getCondVisibility('System.Platform.IOS'):
		return 'Mozilla/5.0 (iPad; CPU OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0 Mobile/15E148 Safari/604.1' # iOS iPhone/iPad
	elif xbmc.getCondVisibility('System.Platform.Darwin') or xbmc.getCondVisibility('System.Platform.OSX'):
		return base.format(f"(Macintosh; Intel Mac OS X 10.15; rv:{REV})") # Mac OSX
	return base.format(f"(X11; Linux x86_64; rv:{REV})") # x64 Linux

def _header(REFERRER=None, WORD=None, USERTOKEN=None):
	header = {}
	header['Cache-Control'] = 'public, max-age=300'
	header['Accept'] = '*/*'
	header['User-Agent'] = get_userAgent()
	header['DNT'] = '1'
	header['Upgrade-Insecure-Requests'] = '1'
	header['Accept-Encoding'] = 'gzip'
	header['Accept-Language'] = 'de-DE,de;q=0.9,en;q=0.8'
	if REFERRER: header['Referer'] = REFERRER
	if WORD and USERTOKEN:
		header[WORD] = USERTOKEN
	return header

def getMultiData(MURLS, method='GET', REF=f"{BASE_URL}/", WAY=None, AUTH=None, timeout=5, retries=2):
	COMBI_NEW, number = [], len(MURLS)
	def download(pos, url):
		UNCHECK = ssl.create_default_context()
		UNCHECK.check_hostname = False
		UNCHECK.verify_mode = ssl.CERT_NONE
		connector = urllib3.PoolManager(block=True, ssl_context=UNCHECK, maxsize=20)
		with connector.request(method, f"{BASE_URL}/mediathek/", headers=_header(REF, WAY, AUTH), preload_content=False, redirect=True, timeout=timeout, retries=retries) as mrs:
			if mrs.status in [200, 201, 202]:
				response = connector.request(method, url, headers=_header(REF, WAY, AUTH), redirect=True, timeout=timeout, retries=retries)
				if response.status in [200, 201, 202]:
					debug_MS(f"(common.getMultiData[1]) === POS : {pos} === REQUESTED URL : {url} === REQUESTED HEADER : {_header(REF, WAY, AUTH)} ===")
					return [pos, url, py3_dec(response.data)]
				else:
					failing(f"(common.getMultiData[1]) ERROR - RESPONSE - ERROR ##### POS : {pos} === STATUS : {response.status} === URL : {url} === DATA : {py3_dec(response.data)} #####")
					return [pos, url, None]
		connector.clear()
	with ThreadPoolExecutor() as executor:
		picker = [executor.submit(download, pos, url) for pos, url in MURLS]
		wait(picker, timeout=30, return_when=ALL_COMPLETED)
		for ii, future in enumerate(as_completed(picker), 1):
			try:
				COMBI_NEW.append(future.result())
			except Exception as exc:
				failing(f"(common.getMultiData[2]) ERROR - EXEPTION - ERROR ##### FUTURE_CONNECT : {future.result()} === FAILURE : {exc} #####")
				dialog.notification(translation(30521).format('DETAILS'), translation(30523).format(exc), icon, 10000)
				executor.shutdown()
		if COMBI_NEW:
			matching = [flop for flop in COMBI_NEW[:] if flop[2] is None]
			if len(matching) == number or len(matching) > 15:
				dialog.notification(translation(30521).format('DETAILS'), translation(30524), icon, 10000)
		return COMBI_NEW

def getContent(url, method='GET', queries='JSON', REF=None, WAY=None, AUTH=None, headers={}, redirects=True, verify=True, data=None, json=None, timeout=30):
	simple, retries, (ANSWER, NEW_CODING) = requests.Session(), 0, (None for _ in range(2))
	if url.startswith('http'):
		try:
			response = simple.request(method, url, headers=_header(REF, WAY, AUTH), allow_redirects=redirects, verify=verify, timeout=timeout)
			ANSWER = response.json() if queries == 'JSON' else response.text if queries == 'TEXT' else response
			debug_MS(f"(common.getContent) === CALLBACK === STATUS : {response.status_code} || URL : {response.url} || HEADER : {_header(REF, WAY, AUTH)} ===")
		except requests.exceptions.RequestException as exc:
			failing(f"(common.getContent) ERROR - EXEPTION - ERROR ##### URL : {url} === FAILURE : {exc} #####")
			dialog.notification(translation(30521).format('URL'), translation(30523).format(exc), icon, 10000)
			return sys.exit(0)
	else:
		def getCollected(suffix_URL, token_TRANSFER=None):
			debug_MS(f"(common.getCollected) === suffix_URL : {suffix_URL} || token_TRANSFER : {token_TRANSFER} ===")
			recentURL = API_JOYN+token_TRANSFER+suffix_URL if token_TRANSFER else API_JOYN+addon.getSetting('joyn_staticCODE')+suffix_URL
			return recentURL
		while not ANSWER and retries < 3: # 2 x Wiederholungen (gesamt=3) für den URL-Request ::: da der Code für die API_BASE evtl. wieder geändert wurde
			retries += 1
			try:
				endURL = getCollected(url, NEW_CODING)
				response = simple.request(method, endURL, headers=_header(REF, WAY, AUTH), allow_redirects=redirects, verify=verify, timeout=timeout)
				response.raise_for_status()
				VALID_JSON = response.json() if queries == 'JSON' else None
				ANSWER = response.json() if queries == 'JSON' else response.text if queries == 'TEXT' else response
				debug_MS(f"(common.getContent) === CALLBACK === RETRIES_no : {retries} === STATUS : {response.status_code} || URL : {response.url} || HEADER : {_header(REF, WAY, AUTH)} ===")
			except Exception as exc: # No JSON object could be decoded
				failing(f"(common.getContent) ERROR - CURRENT_TOKEN - ERROR ##### RETRIES_no : {retries} === URL : {url} === FAILURE : {exc} #####")
				CONTENT = simple.get(BASE_JOYN, headers=_header(REF, WAY, AUTH), allow_redirects=redirects, verify=verify, timeout=10)
				SCAN_REQ = re.compile(r'''</script><script src=["']/_next/static/([^/]+?)/_ssgManifest.js''', re.S).findall(CONTENT.text)
				#SCAN_REQ = re.compile(r'''["']query["']:.*?,["']buildId["']:["']([^"']+)["'],["']isFallback["']''', re.S).findall(CONTENT.text)
				if SCAN_REQ:
					NEW_CODING = SCAN_REQ[0]
					addon.setSetting('joyn_staticCODE', NEW_CODING)
				elif retries > 1 and not SCAN_REQ:
					retries += 2
					dialog.notification(translation(30521).format('URL'), translation(30524), icon, 12000)
					break
				time.sleep(2)
	return ANSWER

def plugin_operate(MARKING):
	check_uno = xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0","id":1,"method":"Addons.GetAddonDetails","params":{{"addonid":"{MARKING}","properties":["enabled"]}}}}')
	answer_uno, answer_due = json.loads(check_uno), json.loads(f'{{"error": "{MARKING} NOT FOUND"}}')
	if not "error" in answer_uno.keys() and answer_uno.get('result', '') and answer_uno['result'].get('addon', {}).get('enabled', False) is False:
		try:
			xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{MARKING}","enabled":true}}}}')
			failing(f"(common.plugin_operate) ERROR - ACTIVATED - ERROR :\n##### Das benötigte Addon : *{MARKING}* ist NICHT aktiviert !!! #####\n##### Es wird jetzt versucht die Aktivierung durchzuführen !!! #####")
		except: pass
		del answer_due
		check_due = xbmc.executeJSONRPC(f'{{"jsonrpc":"2.0","id":1,"method":"Addons.GetAddonDetails","params":{{"addonid":"{MARKING}","properties":["enabled"]}}}}')
		answer_due = json.loads(check_due)
	if (answer_uno.get('result', '') and answer_uno['result'].get('addon', {}).get('enabled', False) is True) or (answer_due.get('result', '') and answer_due['result'].get('addon', {}).get('enabled', False) is True):
		return True
	if answer_due.get('result', '') and answer_due['result'].get('addon', {}).get('enabled', False) is False:
		dialog.ok(addon_id, translation(30501).format(MARKING))
		failing(f"(common.plugin_operate) ERROR - ACTIVATED - ERROR :\n##### Das benötigte Addon : *{MARKING}* ist NICHT aktiviert !!! #####\n##### Eine automatische Aktivierung ist leider NICHT möglich !!! #####")
	if "error" in answer_uno.keys() or "error" in answer_due.keys():
		dialog.ok(addon_id, translation(30502).format(MARKING))
		failing(f"(common.plugin_operate) ERROR - INSTALLED - ERROR :\n##### Das benötigte Addon : *{MARKING}* ist NICHT installiert !!! #####")
	return False

def preserve(store, data=None):
	if data is not None:
		with open(store, 'w') as topics:
			json.dump(data, topics, indent=2, sort_keys=True)
	else:
		with open(store, 'r') as topics:
			arrive = json.load(topics)
		return arrive

def cleaning(text):
	if text is not None:
		for tx in (('&lt;', '<'), ('&gt;', '>'), ('&amp;', '&'), ('&Amp;', '&'), ('&apos;', "'"), ("&quot;", "\""), ("&Quot;", "\""), ('&szlig;', 'ß'), ('&mdash;', '-'), ('&ndash;', '-'), ('&nbsp;', ' '), ('&hellip;', '...'), ('\xc2\xb7', '-'),
			("&#x27;", "'"), ('&#34;', '"'), ('&#39;', '\''), ('&#039;', '\''), ('&#x00c4', 'Ä'), ('&#x00e4', 'ä'), ('&#x00d6', 'Ö'), ('&#x00f6', 'ö'), ('&#x00dc', 'Ü'), ('&#x00fc', 'ü'), ('&#x00df', 'ß'), ('&#xD;', ''),
			('&#xC4;', 'Ä'), ('&#xE4;', 'ä'), ('&#xD6;', 'Ö'), ('&#xF6;', 'ö'), ('&#xDC;', 'Ü'), ('&#xFC;', 'ü'), ('&#xDF;', 'ß'), ('&#x201E;', '„'), ('&#xB4;', '´'), ('&#x2013;', '-'), ('&#xA0;', ' '),
			('&Auml;', 'Ä'), ('&Euml;', 'Ë'), ('&Iuml;', 'Ï'), ('&Ouml;', 'Ö'), ('&Uuml;', 'Ü'), ('&auml;', 'ä'), ('&euml;', 'ë'), ('&iuml;', 'ï'), ('&ouml;', 'ö'), ('&uuml;', 'ü'), ('&#376;', 'Ÿ'), ('&yuml;', 'ÿ'),
			('&agrave;', 'à'), ('&Agrave;', 'À'), ('&aacute;', 'á'), ('&Aacute;', 'Á'), ('&acirc;', 'â'), ('&Acirc;', 'Â'), ('&egrave;', 'è'), ('&Egrave;', 'È'), ('&eacute;', 'é'), ('&Eacute;', 'É'), ('&ecirc;', 'ê'), ('&Ecirc;', 'Ê'),
			('&igrave;', 'ì'), ('&Igrave;', 'Ì'), ('&iacute;', 'í'), ('&Iacute;', 'Í'), ('&icirc;', 'î'), ('&Icirc;', 'Î'), ('&ograve;', 'ò'), ('&Ograve;', 'Ò'), ('&oacute;', 'ó'), ('&Oacute;', 'Ó'), ('&ocirc;', 'ô'), ('&Ocirc;', 'Ô'),
			('&ugrave;', 'ù'), ('&Ugrave;', 'Ù'), ('&uacute;', 'ú'), ('&Uacute;', 'Ú'), ('&ucirc;', 'û'), ('&Ucirc;', 'Û'), ('&yacute;', 'ý'), ('&Yacute;', 'Ý'),
			('&atilde;', 'ã'), ('&Atilde;', 'Ã'), ('&ntilde;', 'ñ'), ('&Ntilde;', 'Ñ'), ('&otilde;', 'õ'), ('&Otilde;', 'Õ'), ('&Scaron;', 'Š'), ('&scaron;', 'š'), ('&ccedil;', 'ç'), ('&Ccedil;', 'Ç'),
			('–', '-'), ("\\'", "'"), ('&shy;', ''), ('<br/> ', '[CR]'), ('<br/>', '[CR]'), ('Ã¶', 'ö')):
			text = text.replace(*tx)
		text = text.strip()
	return text

def cleanGuest(text):
	if text is not None:
		for gt in (('Mit dabei:', '[B]Mit dabei:[/B]'), ('Experte:', '[B]Experte:[/B]'), ('Kommentiert von:', '[B]Kommentiert von:[/B]'),\
			('Moderation:', '[B]Moderation:[/B]'), ('Rateteam:', '[B]Rateteam:[/B]'), ('\n', ' '), ('\t', ' ')):
			text = text.replace(*gt)
	return text

def cleanStation(channelID):
	# ARD, ZDF, RTL, SAT1, PRO7, K1, RTL2, VOX, TELE5, 3SAT, ARTE, 2NEO, FES, SERVU, RTL-N, DMAX, SIXX, SAT1G, PRO7M, RTLPL, WDR, N3, BR, SWR, HR, MDR, RBB, ALPHA, ZINFO, SUPER, KIKA
	channelID = channelID.replace(' Programm', '').replace(' programm', '').replace(' Mediathek', '')
	ChannelCode = ['ARD','Das Erste','ONE','FES','ZDF','2NEO','ZNEO','2INFO','ZINFO','3SAT','ALPHA','Arte','ARTE','BR','DMAX','HR','kabel eins','K1','KIKA',\
		'KiKA','MDR','NDR','N3','ORF','PHOEN','PRO7', 'PRO7M','RBB','SAT1','SAT.1','SAT1G','SAT.1G','SERVU','SIXX','SR','SWR','SWR/SR','WDR',\
		'RTL','RTL2','RTLZWEI','RTL II','RTLPL','RTL-N','SRTL','SUPER RTL','SUPER','TOGGO','TELE5','WELT','VOX']
	if channelID in ChannelCode and channelID != "":
		for sn in ((' ', ''), ('ARD', 'Das Erste'), ('DasErste', 'Das Erste'), ('FES', 'ONE'), ('Arte', 'ARTE'), ('K1', 'Kabel 1'), ('kabeleins', 'Kabel 1'), ('KIKA', 'KiKA'),\
			('2INFO', 'ZDFinfo'), ('ZINFO', 'ZDFinfo'), ('2NEO', 'ZDFneo'), ('ZNEO', 'ZDFneo'), ('3SAT', '3sat'), ('N3', 'NDR'), ('PHOEN', 'PHOENIX'),\
			('PRO7M', 'ProSieben MAXX'), ('PRO7', 'ProSieben'), ('RTLII', 'RTL 2'), ('RTLZWEI', 'RTL 2'), ('RTL-N', 'NITRO'), ('RTLPL', 'RTLup'),\
			('SAT.1G', 'SAT.1 Gold'), ('SAT1G', 'SAT.1 Gold'), ('SAT1', 'SAT.1'), ('SERVU', 'ServusTV Deutschland'), ('SUPERRTL', 'SRTL'), ('SUPER', 'SRTL'),\
			('TELE5', 'TELE 5'), ('TOGGO', 'TOGGO plus')):
			channelID = channelID.replace(*sn)
	if channelID in ['ARD-alpha', 'ALPHA']: channelID = 'ARD alpha'
	if channelID in ['SWR', 'SR', 'SWR/SR']: channelID = 'SWR'
	channelID = '  ('+channelID+')' if channelID != "" else channelID
	studio = channelID.replace('(', '').replace(')', '').replace('  ', '')
	return (channelID, studio)

def create_entries(metadata, SIGNS=None):
	listitem = xbmcgui.ListItem(metadata['Title'])
	vinfo = listitem.getVideoInfoTag() if KODI_ov20 else {}
	if KODI_ov20: vinfo.setTitle(metadata['Title'])
	else: vinfo['Title'] = metadata['Title']
	if metadata.get('Tagline', ''):
		if KODI_ov20: vinfo.setTagLine(metadata['Tagline'])
		else: vinfo['Tagline'] = metadata['Tagline']
	description = metadata['Plot'] if metadata.get('Plot') not in ['', 'None', None] else ' '
	if KODI_ov20: vinfo.setPlot(description)
	else: vinfo['Plot'] = description
	if str(metadata.get('Season')).isdecimal():
		if KODI_ov20: vinfo.setSeason(int(metadata['Season']))
		else: vinfo['Season'] = metadata['Season']
	if str(metadata.get('Episode')).isdecimal():
		if KODI_ov20: vinfo.setEpisode(int(metadata['Episode']))
		else: vinfo['Episode'] = metadata['Episode']
	if str(metadata.get('Duration')).isdecimal():
		if KODI_ov20: vinfo.setDuration(int(metadata['Duration']))
		else: vinfo['Duration'] = metadata['Duration']
	if metadata.get('Aired', ''):
		if KODI_ov20: vinfo.setFirstAired(metadata['Aired'])
		else: vinfo['Aired'] = metadata['Aired']
	if str(metadata.get('Year')).isdecimal():
		if KODI_ov20: vinfo.setYear(int(metadata['Year']))
		else: vinfo['Year'] = metadata['Year']
	if metadata.get('Genre', ''):
		if KODI_ov20: vinfo.setGenres([metadata['Genre']])
		else: vinfo['Genre'] = metadata['Genre']
	if metadata.get('Director', ''):
		if KODI_ov20: vinfo.setDirectors([metadata['Director']])
		else: vinfo['Director'] = metadata['Director']
	if metadata.get('Cast', '') and isinstance(metadata.get('Cast'), (list, tuple)):
		if KODI_ov20: vinfo.setCast(metadata['Cast'])
		else: listitem.setCast(metadata['Cast'])
	if metadata.get('Rating', ''):
		if KODI_ov20: vinfo.setRating(float(metadata['Rating']), 0, 'imdb', True) # vinfo.setRating(4.6, 8940, "imdb", True) since NEXUS and UP
		else: listitem.setRating('imdb', float(metadata['Rating']), 0, True) # LSM.setRating("imdb", 4.6, 8940, True) below NEXUS (MATRIX)
	if metadata.get('Studio', ''):
		if KODI_ov20: vinfo.setStudios([metadata['Studio']])
		else: vinfo['Studio'] = metadata['Studio']
	if metadata.get('Mpaa', ''):
		if KODI_ov20: vinfo.setMpaa(metadata['Mpaa'])
		else: vinfo['Mpaa'] = metadata['Mpaa']
	if metadata.get('Mediatype', ''):
		if KODI_ov20: vinfo.setMediaType(metadata['Mediatype'])
		else: vinfo['Mediatype'] = metadata['Mediatype']
	picture = metadata['Image'] if metadata.get('Image') else icon
	listitem.setArt({'icon': icon, 'thumb': picture, 'poster': picture, 'fanart': defaultFanart})
	if useThumbAsFanart and not artpic in picture:
		listitem.setArt({'fanart': picture})
	if metadata.get('Reference') == 'Single':
		listitem.setProperty('IsPlayable', 'true')
	if not KODI_ov20: listitem.setInfo('Video', vinfo)
	return listitem
